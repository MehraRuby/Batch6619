package AnnotationEx;


@MyCustomAnnotation( myStr = "sample string 1")
public class MyDemo 
{
	@MyCustomAnnotation( myStr = "param const" ,myVal=70 )
	MyDemo(String a)
	{
		System.out.println("Param const....");		
	}
	
	@MyCustomAnnotation( myStr = "sample string" ,myVal=80 )
	public String getString()
	   {
	      return null;
	   }

	@MyCustomAnnotation( myStr = "sample integer" ,myVal=90 )
	public Integer getInteger()
		{
		return null;		
		}
}

