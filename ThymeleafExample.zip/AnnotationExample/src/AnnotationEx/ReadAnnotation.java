package AnnotationEx;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;



public class ReadAnnotation
{
	public static void main(String... g)
	{
		 try
	      {
			 Class<MyDemo> obj= MyDemo.class;
		      					      		      		      		      		      		      		      		      	
		      	Method m= obj.getMethod("getInteger", new Class[]{});
				readAnnotationOn(m);
				
			//	Constructor c = obj.getConstructor(new Class<MyDemo>());
			//	readAnnotationOn(c);
												
	      }
		 catch(Exception e){System.out.println(e);}			 			 
	}
	
	
	

	static void readAnnotationOn(AnnotatedElement element)
	   {
	      try
	      {
	         System.out.println("\n Finding annotations on " + element.getClass().getName());
	        
	         Annotation[] an = element.getAnnotations();
	      
	         for (Annotation at : an)	        	
	         {
	            if (at instanceof MyCustomAnnotation)
	            {
	            	MyCustomAnnotation f= (MyCustomAnnotation) at;
	               System.out.println("mystr :" + f.myStr()+"       myval :" + f.myVal());
	            }
	         }
	      } catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	   }

	
}
