package Comparision;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Student implements Comparable<Student>
{
	int stid;
	String name;
	int age;
	
	Student(){}
	
	Student(int id,String  nm,int a)
	{
		stid =id;
		name =nm;
		age = a;			
	}
	
	public String toString()
	{
		return "Stid : "+stid+" Name :  "+name+" Age : "+age;	
	}
	
	
	public int compareTo(Student obj) 
	{	
		if(obj.age == age)
					return 0;
		else if(obj.age < age)
				return 1;
		else 
				return -1;
	}
	
}

class STID extends Student implements  Comparable<Student>
{
	public int compareTo(Student o)
	{		
		if(o.stid == stid)
				return 0;
		else if(o.stid < stid)
				return 1;
		else 
				return -1;
	}
	
}

public class ComparableExample
{
	public static void main(String... g)
	{
		List<Student> AL = new ArrayList<Student>();
		AL.add(new Student(101,"pooja",24));
		AL.add(new Student(102,"mohan",25));
		AL.add(new Student(104,"william",23));
		AL.add(new Student(106,"happy",22));
		AL.add(new Student(103,"aman",28));
		AL.add(new Student(107,"amar",27));
		AL.add(new Student(105,"amit",26));
		
		Collections.sort(AL);
		
		AL.forEach(m->System.out.println(m));
						
	}	
}










