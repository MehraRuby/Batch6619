package Comparision;



import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Student1
{
	int stid;
	String name;
	int age;
	
	Student1(){}
	
	Student1(int id,String  nm,int a)
	{
		stid =id;
		name =nm;
		age = a;			
	}
	
	public String toString()
	{
		return "Stid : "+stid+" Name :  "+name+" Age : "+age;	
	}
}

class Age  implements  Comparator<Student1>
{
	public int compare(Student1 st1, Student1 st2)
	{
			if(st1.age == st2.age)
					return 0;
			else if(st1.age < st2.age)
					return -1;
			else 
					return 1;
	}	
}


class Name  implements  Comparator<Student1>
{
	public int compare(Student1 st1, Student1 st2)
	{
			if(st1.name.compareTo(st2.name)==0)
				return 0;
			else if(st1.name.compareTo(st2.name)<0)
					return -1;
			else 
					return 1;
	}	
}


public class ComparatorExample
{
	public static void main(String... g)
	{
		List<Student1> AL = new ArrayList<Student1>();
		AL.add(new Student1(101,"pooja",24));
		AL.add(new Student1(102,"mohan",25));
		AL.add(new Student1(104,"william",23));
		AL.add(new Student1(106,"happy",22));
		AL.add(new Student1(103,"aman",28));
		AL.add(new Student1(107,"amar",27));
		AL.add(new Student1(105,"amit",26));
		
		Collections.sort(AL, new Age());
		
		AL.forEach(m->System.out.println(m));
		
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		Collections.sort(AL, new Name());
		
		AL.forEach(m->System.out.println(m));
						
	}	
}

