package GenericExample;

class GenKeyValue<K,V>
{

	K k1;
	V v1;
	
	void setKey(K obj)
	{
		this.k1 = obj;
	}
	
	K getKey()
	{
		return k1;
	}
	
	void setValue(V obj)
	{
		this.v1 = obj;
	}
	
	V getValue()
	{
		return v1;
	}
}


public class Gen_Multi 
{
public static void main(String... g)
	{
	GenKeyValue<Integer,String> obj1 = new GenKeyValue<Integer,String> ();
	obj1.setKey(12);
	obj1.setValue("Aman");
	System.out.println(obj1.getKey()+"   -     "+obj1.getValue());
	
	GenKeyValue<Integer,Student> obj2 = new GenKeyValue<Integer,Student> ();
	obj2.setKey(1);
	obj2.setValue(new Student(101,"Pooja"));
	System.out.println(obj2.getKey()+"   -     "+obj2.getValue());
		
	
	
	}	
}
