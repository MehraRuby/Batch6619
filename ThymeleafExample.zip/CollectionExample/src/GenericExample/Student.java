package GenericExample;

public class Student 
{
	int stid;
	String stnm;
	
	Student(int d,String n)
	{
		stid = d;
		stnm = n;
	}
	
	public String toString()
	{
		return "Stid: "+stid+"  Name: "+stnm;
	}

}
