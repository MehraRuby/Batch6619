package GenericExample;

// generic class

class Gen <T>
{
	 T obj;
	 
	 Gen(T ob)
	 {
		 this.obj = ob;
	 }
	 
	void setValue(T ob)
	{
		this.obj = ob;
	}
	
	T getValue()
	{
		return obj;
	}	
}

class Test
{
	public static void main(String... g)
	{
		Gen<String> obj = new Gen("Hello");
		System.out.println(obj.getValue());
		obj.setValue("Java");
		System.out.println(obj.getValue());
		
		Gen<Integer> IT = new Gen(7899);
		System.out.println(IT.getValue());
		IT.setValue(9000);
		System.out.println(IT.getValue());
		
		Gen<Student> G2 = new Gen(new Student(101,"Mohan"));
		System.out.println(G2.getValue());
		G2.setValue(new Student(102,"Gopal"));
		System.out.println(G2.getValue());
		
	}	
}
