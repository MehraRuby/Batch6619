package ListExamples;

import java.util.*;

public class ArrayListExample 
{
	public static void main(String... g)
	{
		List<Integer> L = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		// 1 way
		
		System.out.println(L);
		
		//2 way
		
		for (Integer I :L)
		{
			System.out.print(I+"\t");
		}
		
		System.out.println("\n");
		
		//3 way
		
		Iterator I = L.iterator();
		while(I.hasNext())
		{
			System.out.print((Integer)I.next()+"\t");
		}
		
		System.out.println("\n");
			
		//4 way 
		
		ListIterator LI = L.listIterator();
		while(LI.hasNext())
		{
			System.out.print((Integer)LI.next()+"\t");
		}
		while(LI.hasPrevious())
		{
			System.out.print((Integer)LI.previous()+"\t");
		}
		
		//5 way
		
		System.out.println("\n");
		
		L.forEach(m ->  {System.out.print(m);}	);
								
	}	
}
