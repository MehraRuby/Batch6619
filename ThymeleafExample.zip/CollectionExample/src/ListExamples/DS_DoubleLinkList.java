package ListExamples;

public class DS_DoubleLinkList 
{
			 class Node 
			 {
				    Node prev;
				 	int data;
				 	Node next;		
				 	
				 	Node(int d,Node n,Node p)
				 	{
				 		this.data=d;
				 		this.next = n;
				 		this.prev=p;
				 	}			 				 				 				 		
			 }
			 
			 Node start = null;
			 Node last=null;
			 
			 void create(int d)
			 {
				 Node newnode = new Node(d,null,null);
				 
				 if(start ==  null)
				 {
					 start= newnode;
					 last = newnode;
				 }
				 else
				 {
					 newnode.prev = last;
					 last.next=newnode;
					 last = newnode;				
				 }
			 }
			 
			 void display()
			 {
				 Node temp = start;
				 Node pr = last;
				 while(temp != null)
				 {
					 System.out.print(temp.data+"\t");
					 temp = temp.next;
				 }
				 System.out.println("\n\n==============================");
				 while(pr != null)
				 {
					 System.out.print(pr.data+"\t");
					 pr = pr.prev;
				 }
			 }
		
			 public static void main(String... g)
			 {
				 DS_DoubleLinkList SL = new DS_DoubleLinkList();
				 
				 for(int i=1 ;i<=10 ;i++)
				 {
					 SL.create(i);
				 }
				 
				 SL.display();			 			 		
			 }		
	}



