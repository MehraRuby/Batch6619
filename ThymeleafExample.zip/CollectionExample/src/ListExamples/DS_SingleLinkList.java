package ListExamples;

public class DS_SingleLinkList 
{
		 class Node 
		 {
			 	int data;
			 	Node next;		
			 	
			 	Node(int d,Node n)
			 	{
			 		this.data=d;
			 		this.next = n;
			 	}			 				 				 				 		
		 }
		 
		 Node start = null;
		 Node last=null;
		 
		 void create(int d)
		 {
			 Node newnode = new Node(d,null);
			 
			 if(start ==  null)
			 {
				 start= newnode;
				 last = newnode;
			 }
			 else
			 {
				 last.next = newnode;
				 last = newnode; 
			 }
		 }
		 
		 void display()
		 {
			 Node temp = start;
			 while(temp != null)
			 {
				 System.out.println(temp.data);
				 temp = temp.next;
			 }
		 }
	
		 public static void main(String... g)
		 {
			 DS_SingleLinkList SL = new DS_SingleLinkList();
			 
			 for(int i=1 ;i<=10 ;i++)
			 {
				 SL.create(i);
			 }
			 
			 SL.display();			 			 		
		 }		
}
