package ListExamples;

import java.util.Enumeration;
import java.util.Vector;

public class EnumerationExample 
{
	public static void main(String... g)
	{
		Vector<Integer> v = new Vector<Integer>();
		
		v.add(100);
		v.add(200);
		v.add(400);
		v.add(500);
		
		Enumeration<Integer> e = v.elements();
		while(e.hasMoreElements()) 
		{
			System.out.println(e.nextElement());				
		}
		
		
	}
}
