package ListExamples;

import java.util.LinkedList;
import java.util.stream.Collectors;

public class LinkedListExample
{
	public static void main(String... g)
	{
		LinkedList<String> L = new LinkedList<String>();
		
		L.add("pooja");
		L.add("zzzz");
		L.add("eee");
		L.add("rrrrr");
		L.add("ccccc");
		
		L.stream().map(String::toUpperCase).collect(Collectors.toList())
		.forEach(
				m->System.out.println(m)
				);
		
		LinkedList<Integer> L1 = new LinkedList<Integer>();
		
		L1.add(1);
		L1.add(2);
		L1.add(3);
		L1.add(4);
		L1.add(5);
		L1.add(6);
		
		L1.stream().map(m->m*2).collect(Collectors.toList())
		.forEach(
				m->System.out.println(m)
				);
		
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
		
		L1.stream().filter(m->m>=4).collect(Collectors.toList())
		.forEach(
				m->System.out.println(m)
				);
		
		
		
	}	
}
