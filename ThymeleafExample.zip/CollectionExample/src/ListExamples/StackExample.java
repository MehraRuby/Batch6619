package ListExamples;

import java.util.Stack;

public class StackExample 
{
public static void main(String... g)
		{
			Stack<String> S = new Stack<String>();
			S.push("aaaa");
			S.push("bbb");
			S.push("ccc");
			S.push("dddd");
			S.push("wwww");
			S.push("qqqq");
			
		//	S.forEach(m->{System.out.println(m);});
			S.pop();
			
			S.forEach(m->{System.out.println(m);});
			
			System.out.println(S.peek());
		
		}
}
