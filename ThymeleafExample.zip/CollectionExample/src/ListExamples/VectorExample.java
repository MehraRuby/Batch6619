package ListExamples;

import java.util.Vector;
import java.util.ArrayList;

public class VectorExample 
{
public static void main(String...g)
	{
	Vector V  = new Vector();
	
	V.add("Java");
	V.add(90);
	V.add(90.90);
	
	for(Object O : V)
	{
		System.out.println(O);
	}
	
	ArrayList V1  = new ArrayList();
	
	V1.add("Java");
	V1.add(90);
	V1.add(90.90);
	
	for(Object O : V1)
	{
		if(O instanceof String)
			System.out.println("String" +O);
		
		if(O instanceof Integer)
			System.out.println("Integer" +O);
		
		if(O instanceof Double)
			System.out.println("Double" +O);
		
		
	}
	
	}
}
