package MapExample;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapExample 
{
	public static void main(String...  g)
	{
		HashMap<Integer,String> H = new HashMap<Integer,String>();
		
		H.put(101, "pooja");
		H.put(102, "mohan");
		H.put(103, "krishan");
		H.put(104, "aman");
		H.put(101, "happy");
		H.put(105, "well");
		H.put(106, "good");
		
		Set<Map.Entry<Integer,String>> S = H.entrySet(); 
		
		S.forEach(m->System.out.println(m.getKey()+"  "+m.getValue()));
						
	}	
}
