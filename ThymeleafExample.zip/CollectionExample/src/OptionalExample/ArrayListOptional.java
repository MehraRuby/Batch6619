package OptionalExample;

import java.util.ArrayList;
import java.util.Optional;

public class ArrayListOptional
{
		public static void main(String... g) 
			{    
				ArrayList<String> z = new ArrayList<String>();
				z.add("pooja");
				
				Optional<ArrayList<String>> I = Optional.of(z);
				
				Optional<ArrayList<String>> IL = Optional.empty();
				
				
				System.out.println(I.orElse(null));
				System.out.println(IL.orElse(null));
				
				
				//System.out.println(I.orElseThrow(()->"Default value"));
			//	System.out.println(IL.orElseGet(()->"Default value"));
															
	}  

	}


