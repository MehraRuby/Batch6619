package OptionalExample;
import java.util.Optional; 


public class Else_OptionalExample 
{ 
   public static void main(String... g) 
			{    
				String z = new String("Hello");
				Optional<String> I = Optional.of(z);
				
				Optional<String> IL = Optional.empty();
				
				
				System.out.println(I.orElse("Default value"));
				System.out.println(IL.orElse("Default value"));
				
				
				System.out.println(I.orElseGet(()->"Default value"));
				System.out.println(IL.orElseGet(()->"Default value"));
				
				
			
							
   }  
}