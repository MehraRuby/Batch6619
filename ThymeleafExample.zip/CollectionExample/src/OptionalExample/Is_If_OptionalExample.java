package OptionalExample;
import java.util.Optional; 


public class Is_If_OptionalExample 
{ 
   public static void main(String... g) 
			{    
				Integer z = new Integer(90);
				
				Optional<Integer> I = Optional.of(z);
							
				if(I.isPresent())
					{
					System.out.println("Value is present");
					}
				else
					{
					System.out.println("Value is not Present");
					}
				
				System.out.println("________________________________________");
				
				
				
				
				Optional<Integer> IL = Optional.empty();
				
				I.ifPresent(s->System.out.println("Value is assigned"));
				IL.ifPresent(s->System.out.println("Value is not assigned"));
			
							
   }  
}