package OptionalExample;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Optional;

public class Is_If_Optional_TreeSet 
{
	   public static void main(String... g) 
				{    
		   				int count=0;
		   			
		   				
		   				HashSet<Integer> C = new HashSet<Integer>();
		   			
		   				C.add(78);
		   				C.add(54);		   				
		   				C.add(74);
		   				C.add(97);
		   				C.add(null);
		   				C.add(89);
		   				C.add(null);
		   				C.add(10);
		   				C.add(10);
		   				
		   				HashSet<Integer> M = new HashSet<Integer>();
		   				
		   				
		   				Optional <HashSet<Integer>> IO = Optional.ofNullable(C);
		   				
		   			   Optional<HashSet<Integer>> IL = Optional.empty();
		   				
		   				Optional <HashSet<Integer>> HM = Optional.ofNullable(M);
		   							   				 
		   				System.out.println(IO.orElse(null));
						System.out.println(IL.orElse(null));			
		   					
						System.out.println(HM.orElse(null));		
		   						   						   								   						   						   						   						   						   						   						   						   
				}	
}
