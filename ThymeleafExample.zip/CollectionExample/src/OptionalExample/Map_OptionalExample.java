package OptionalExample;
import java.util.Optional; 


public class Map_OptionalExample 
{ 
   public static void main(String... g) 
			{    
				String z = new String("programming");
				Optional<String> I = Optional.of(z);
				
							
				System.out.println(I.map(String::toUpperCase));
				System.out.println(I.filter(s->s.equals("PROGRAMMING")));
				System.out.println(I.filter(s->s.equalsIgnoreCase("PROGRAMMING")));
											
   }  
}