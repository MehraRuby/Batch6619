package OptionalExample;
import java.util.Optional; 


public class OptionalExample 
{ 
   public static void main(String... g) 
			{    
				Integer a[] = new Integer[10];
				Optional<Integer> I = Optional.ofNullable(a[5]);
				if(I.isPresent())
					{
					System.out.println("Value is present");
					}
				else
					{
					System.out.println("Value is not Present");
					}
				
				System.out.println("________________________________________");
				
				Integer b[] = new Integer[]{1,2,3,4,5,6,7,8,9,10};
				
				Optional<Integer> IL = Optional.ofNullable(b[5]);
				if(IL.isPresent())
					{
					System.out.println("Value is present");
					}
				else
					{
					System.out.println("Value is not Present");
					}			
   }  
}