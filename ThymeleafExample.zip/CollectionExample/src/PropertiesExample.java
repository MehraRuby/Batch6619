
import java.io.FileInputStream;
import java.util.Properties;
import java.util.Enumeration;


public class PropertiesExample
{
	public static void main(String... g)
	{
		Properties p = new Properties();
		try
		{
		FileInputStream F = new FileInputStream("application.properties");				
		p.load(F);
		Enumeration e1 = p.propertyNames();
		while(e1.hasMoreElements())
		{
			String k =(String) e1.nextElement();
			String v = p.getProperty(k);
			
			System.out.println(k+"   "+v);					
		}
		
		System.out.println("=========================================");
		p = System.getProperties();
		Enumeration e2 = p.propertyNames();
		while(e2.hasMoreElements())
		{
			String k =(String) e2.nextElement();
			String v = p.getProperty(k);
			
			System.out.println(k+"   "+v);					
		}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
							
	}	
}
