package QueueExample;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample 
{
	public static void main(String... g)
	{
		Queue<Integer> Q = new LinkedList<Integer>();
		Q.add(100);
		Q.add(200);
		Q.add(300);
		Q.add(400);
		Q.add(500);
		Q.add(600);
		
		System.out.println("Top element : "+Q.peek());
		System.out.println("Remove element : "+Q.remove());
		System.out.println("Poll element : "+Q.poll());
		System.out.println("Search element : "+Q.offer(500));
		System.out.println("Now Top element : "+Q.peek());
			
	}
	
}
