package SetExample;

import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Collection;

public class TreeSetExample
{
	public static void main(String... g)
	{
		TreeSet<String> TS = new TreeSet<String>();
		TS.add("Option 1");
		TS.add("Option 7");
		TS.add("Option 2");
		TS.add("Option 9");
		TS.add("Option 1");
			
		
/*		for(String s : TS)
		{
			System.out.println(s);
		}
		*/
		
		TS.stream().map(String::toUpperCase).collect(Collectors.toList()).forEach(m->System.out.println(m));
		
		
		
		TreeSet<Integer> TS1 = new TreeSet<Integer>();
		TS1.add(900);
		TS1.add(34);
		TS1.add(320);
		TS1.add(12);
		TS1.add(15);
		
		
		TS1.stream().filter(m -> (m > 100)).collect(Collectors.toList()).forEach(p->System.out.println(p));
		
		HashSet<String> HS = new HashSet<String>();
		HS.add("option 1");
		HS.add("option 2");
		HS.add("option 3");
		HS.add("option 4");
		HS.add("option 5");
		
		HS.forEach(m->System.out.println(m));
		
		Collection<Integer> C = new HashSet<Integer>();
		C.add(78);
		C.add(54);
		C.add(32);
		C.add(74);
		C.add(97);
		C.add(12);
		
		
		LinkedHashSet<Integer> LH = new LinkedHashSet<Integer>();
		LH.add(900);
		LH.addAll(C);
		
		System.out.println(LH);
		
		System.out.println(LH.contains(74));
		
		Object arr[] =LH.toArray();
		
		for(Object i : arr)
		{
			System.out.println((Integer)i);
		}
		
	}	
}
