package SolutionQuestion;

public class Customer
{
	int accno;
	String name;
	long balance;
	int pincode;
	
	Customer(int a,String n,long bal,int p)
	{
		this.accno =a;
		this.name = n;
		this.balance = bal;
		this.pincode = p;
	}
	
	
	public String toString()
	{
		return accno+"  |  "+name+"  |  "+balance+"  |  "+pincode;	
	}
		
}
