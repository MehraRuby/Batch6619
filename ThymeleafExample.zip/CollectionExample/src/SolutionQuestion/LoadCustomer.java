package SolutionQuestion;

import java.util.List;
import java.util.ArrayList;

public final class LoadCustomer
{
	private LoadCustomer(){}
	
	static List<Customer> AL = null;
	
	static
	{
		AL = new ArrayList<Customer>();		
	}
	
	public static void load()
	{
		AL.add(new Customer(101,"pooja",10000,1234));
		AL.add(new Customer(102,"mohan",20000,2345));
		AL.add(new Customer(103,"william",15000,3456));
		AL.add(new Customer(104,"bob",19000,4567));
		AL.add(new Customer(105,"keshav",30000,5678));
		AL.add(new Customer(106,"jack",50000,6789));
	}	
}
