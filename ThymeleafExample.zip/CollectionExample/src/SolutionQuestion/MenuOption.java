package SolutionQuestion;


import java.util.Scanner;


public class MenuOption 
{
	public static void main(String... g)
	{
		Operations obj = new Operations();
		
		int ch;
		String str;
		
		while(true)
		{
		System.out.println("\n Main Menu");
		System.out.println("\n 1: Money Transfer");
		System.out.println("\n 2: Withdraw");
		System.out.println("\n 3: Detail of a Customer");
		System.out.println("\n 4: Customer List");
		
		System.out.println("\n Enter your choice: ");
		Scanner sc = new Scanner(System.in);
		ch =sc.nextInt();
		
		switch(ch)
		{
		case 1:
				System.out.println("\nFrom Which Accno: ");
				int from= sc.nextInt();
				System.out.println("\nEnter pincode: ");
				int fpin = sc.nextInt();
				
				System.out.println("\nTo which Accno : ");
				int to = sc.nextInt();
				
				System.out.println("\nAmount to transfer : ");
				long amt = sc.nextLong();
			
				obj.deposit(from,to,fpin,amt);
				break;
				
		case 2:			
					System.out.println("\nFrom Which Accno: ");
					from= sc.nextInt();
					System.out.println("\nEnter pincode: ");
					fpin = sc.nextInt();
					System.out.println("\nAmount to transfer : ");
					amt = sc.nextLong();
							
					obj.withdraw(from,fpin,amt);
					break;
				
		case 3:
				System.out.println("\nEnter account no : ");
				int a = sc.nextInt();
				System.out.println("\nEnter pincode: ");
				int pin = sc.nextInt();
				
				obj.detail(a,pin);
				break;		
		case 4: 
				obj.customerlist();
				break;
		}
		
		System.out.println("\nDo you want to continue: ");
		str = sc.next();
		if(str.equals("N") || str.equals("n"))
		{
			System.exit(0);
		}
		
		}
		
	}
}
