package SolutionQuestion;

import java.util.stream.Collectors;

public class Operations 
{
	Operations(){ LoadCustomer.load(); }
	
	
	void customerlist()
	{
		LoadCustomer.AL.forEach(m->{System.out.println(m);});
	}
	
	
	void detail(int a, int pin)
	{		
		/*for(Customer m :LoadCustomer.AL)
					{
						if(m.accno == a && m.pincode == pin)
															{
															System.out.println(m);
															break;
															}					
					}		*/
		
	LoadCustomer.AL.stream().filter(m->m.accno == a && m.pincode == pin).collect(Collectors.toList())	
	.forEach(m->{System.out.println(m);});
	}
	
	void deposit(int from, int to, int pin, long bal)
	{
		int i=0,j=0,temp=0;
		for(Customer c : LoadCustomer.AL)
		{
			if(c.accno ==from && c.pincode == pin)
			{
				i = temp;
			}
			
			if(c.accno == to)
			{
				j=temp;
			}
			
			temp++;
		}
		
		LoadCustomer.AL.get(i).balance = 	LoadCustomer.AL.get(i).balance - bal;		
		LoadCustomer.AL.get(j).balance = 	LoadCustomer.AL.get(j).balance + bal;
	}
	
	void withdraw(int from,int pin,long bal)
	{
		int i=0,temp=0;
		for(Customer c : LoadCustomer.AL)
		{
			if(c.accno ==from && c.pincode == pin)
			{
				i = temp;
				break;
			}
			temp++;
		}
		
		LoadCustomer.AL.get(i).balance = 	LoadCustomer.AL.get(i).balance - bal;	
					
	}

}
