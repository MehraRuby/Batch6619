package mypack;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DATETIMEDEMO1
{
public static void main(String... g)
	{
		// get all dates in b/w two dates
	
		LocalDate startdate = LocalDate.now();
		LocalDate enddate = startdate.plusMonths(2);
		
		System.out.println("Start Date : "+startdate);
		System.out.println("End Date : "+enddate);
		
		long noofDays = ChronoUnit.DAYS.between(startdate, enddate);
		List<LocalDate> L = Stream.iterate(startdate,d -> d.plusDays(1)).limit(noofDays).collect(Collectors.toList());
				
		System.out.println("No of Days : "+L.size());
		
		System.out.println(L);
		
		ChronoUnit u = ChronoUnit.DAYS.WEEKS;
		ChronoUnit h = ChronoUnit.HOURS;  // check
		
		System.out.println(u.between(startdate, enddate));
		System.out.println(h.between(startdate, enddate));
		
		
		

	}
}
