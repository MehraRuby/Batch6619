package mypack;
import java.time.*;

import java.util.*;

public class DAYSPLUSMINUS 
{
	public static void main(String ... g)
	{
		LocalDateTime TD = LocalDateTime.now();
	//	LocalDateTime TM = TD.plusDays(1);
	//	LocalDateTime YES = TD.minusDays(1);
		
	//System.out.println(TD);
//	System.out.println(TM);
//	System.out.println(YES);
//		
	LocalDateTime NM = TD.plusMonths(1);
		LocalDateTime PM = TD.minusMonths(1);
//		
	LocalDateTime NY= TD.plusYears(1);
		LocalDateTime PY = TD.minusYears(1);
//		
		System.out.println(NM+"   "+PM);
		System.out.println(NY+"   "+PY);
		
		System.out.println(Year.now());
			
		if (Year.now().isLeap())
		{
			System.out.println("Current year is a leap year");							
		}
		else
		{
			System.out.println("Current year is a not leap year");	
		
		}
		
		
		
			
	}
	

}
