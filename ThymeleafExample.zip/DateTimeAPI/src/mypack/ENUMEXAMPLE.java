/* * * * * * 
 * enum is a special class to represent a group of constant
 * 
 * 
 */
package mypack;

public class ENUMEXAMPLE
{
	enum Level
	{
		LOW, MEDIUM,HIGH			
	}
	
	public static void main(String... g)
	{
		Level ref = Level.MEDIUM;
		System.out.println(ref);
		
		
		switch(ref){
			case LOW:
				System.out.println("Low");
				break;
			case MEDIUM:
				System.out.println("Medium");
				break;
			case HIGH:
				System.out.println("High");
				break;
		}
		
		
		for(Level n : Level.values())
		{
			System.out.println(n+" "+n.ordinal());
		}	
			
		System.out.println(Level.valueOf("HIGH"));
					
	}
	
}
