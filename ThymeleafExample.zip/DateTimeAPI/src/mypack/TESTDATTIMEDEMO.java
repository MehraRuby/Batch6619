package mypack;
/*java.time
 * java.util
 * Class :  LocalDate, LocalTime , LocalDateTime, ZonedDateTime,Duration, Instant
 *  * * * * * 
 */

import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class TESTDATTIMEDEMO 
{
	public static void main(String... g)
	{
		//getting current date and time
		LocalTime CT = LocalTime.now();
		LocalDate DT = LocalDate.now();
		LocalDateTime CDT= LocalDateTime.now();
		
		System.out.println(CT+"\n"+DT+"\n"+CDT);
		
		
		
		//Parsing date and Time
		String dateStr = "2020-04-23 12:30";
		DateTimeFormatter DF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");		
		LocalDateTime PDT = LocalDateTime.parse(dateStr,DF);
			
		System.out.println(PDT);
				
		if(PDT.toLocalDate().isLeapYear())
			System.out.println("Leap");
		else
			System.out.println("Not a Leap Year");
		
												
		//Format a date
		LocalDateTime CDT1= LocalDateTime.now();
		DateTimeFormatter DFT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
		String str = CDT1.format(DFT);
		System.out.println(str);
		
				
	}
}
