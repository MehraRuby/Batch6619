package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Entity.users;
import ServiceLayer.DoughNutServiceImpl;


public class CheckUser extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	RequestDispatcher rs;
	public static  DoughNutServiceImpl doughserv; 
		
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{			
		HttpSession session = request.getSession() ;
		
		doughserv = new 	DoughNutServiceImpl();
		
			String usr = request.getParameter("usr");
			String pass = request.getParameter("pwd");
			
			users u = new users();			
			u.setUsername(usr);
			u.setPassword(pass);
					
			if (doughserv.validateUser(u))
			{
				rs = request.getServletContext().getRequestDispatcher("/success.jsp");	
				session.setAttribute("usrnm", usr);
				rs.forward(request, response);	
			}
			else
			{
				PrintWriter p = response.getWriter();
				response.setContentType("text/html");
				
				rs = request.getServletContext().getRequestDispatcher("/index.jsp");
				p.println("<span style=\'color:red;\'>  Invalid Credentials  </span>");
				rs.include(request, response);	
			}			
			
	}

}
