package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ExceptionClasses.CheckDoughQty;
import ExceptionClasses.InvalidQuantityException;
import ServiceLayer.DoughNutServiceImpl;

	
public class DoughnutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rs;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		Integer dnm = Integer.parseInt(request.getParameter("dnm"));
		String size = request.getParameter("r1").trim().toLowerCase();
		int  qty = Integer.parseInt(request.getParameter("qty"));
		System.out.println(size);
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
				
		try
		{					
		double p = CheckUser.doughserv.getDoughPrice(dnm);
		
		if(size.equals("small"))
			p = p-30;
		
		if(size.equals("premimum"))
			p = p+50;
				
		new CheckDoughQty().checkQty(qty);
		
		
		rs = request.getServletContext().getRequestDispatcher("/PlaceOrder.jsp");
		pw.println("<span style=\'color:blue;\'> Order placed successfully!!Total bill amount to be paid "+(p*qty)+ " </span>");	
		
		rs.include(request, response);	
											
		}
		catch(InvalidQuantityException e)
		{	
			rs = request.getServletContext().getRequestDispatcher("/PlaceOrder.jsp");
			pw.println("<span style=\'color:red;\'> "+e+ " </span>");		
			rs.include(request, response);	
		}
														
	}

}
