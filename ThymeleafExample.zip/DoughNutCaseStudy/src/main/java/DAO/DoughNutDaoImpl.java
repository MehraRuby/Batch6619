package DAO;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import Entity.dough_order;
import Entity.doughnut_tbl;
import Entity.users;
import HibernateUtility.ConnectionCls;

@SuppressWarnings("unchecked")
public class DoughNutDaoImpl implements IDoughNutDao
{
	static SessionFactory sf;
	
	static 
	{
		sf = 	ConnectionCls.getSessionFactory();
		System.out.println("SessionFactory is working ! ");
	}
	
	public boolean validateUser(users u)
	{
		Session S = sf.openSession();			
		S.getTransaction().begin();
		
			
		Query q = S.createQuery("from users u where u.username='"+u.getUsername()+"'");
						
		List<users> LST = q.list();		
		Iterator I = LST.iterator();
		
		users u1 = new users();
				
		while(I.hasNext())
		{
			u1 = (users)I.next();
			if (u1.getUsername().equals(u.getUsername()))
			{
				return true;	
			}
		}
		S.close();
		return false;		
	}

	public dough_order placeOrder(dough_order dord) {
		
		return null;
	}

	public List<doughnut_tbl> getDoughnuts() 
	{
		Session S = sf.openSession();			
		S.getTransaction().begin();
		
		Criteria dg = S.createCriteria(doughnut_tbl.class);
		List<doughnut_tbl> L = dg.list();		
		S.close();
		return L;
	}
	
	public Double getDoughPrice(int id)
	{
		double pr=0.0D;
		Session S = sf.openSession();			
		S.getTransaction().begin();
					
		Query q = S.createQuery("from doughnut_tbl d where d.dough_id="+id);
						
		List<users> LST = q.list();		
		Iterator I = LST.iterator();
		
		doughnut_tbl d1 = new doughnut_tbl();
				
		while(I.hasNext())
		{
			d1 = (doughnut_tbl)I.next();
			pr = d1.getDough_price();
		}
		S.close();
		return pr;				
	}

}
