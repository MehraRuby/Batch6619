package DAO;

import java.util.List;

import Entity.dough_order;
import Entity.doughnut_tbl;
import Entity.users;


public interface IDoughNutDao 
{
	boolean validateUser(users u);
	dough_order placeOrder(dough_order dord);
	List<doughnut_tbl>getDoughnuts();	
	Double getDoughPrice(int id);
	
}
