package Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dough_order")
public class dough_order
{
	
	@Id
	private int orderid;
	
	@Column(name="dough_id")
	private int dough_id;
	
	@Column(name="dough_size")
	private String dough_size;
	
	@Column(name="dough_qty")
	private int dough_qty;
	
	@Column(name="bill")
	private double bill;
	
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getDough_id() {
		return dough_id;
	}
	public void setDough_id(int dough_id) {
		this.dough_id = dough_id;
	}
	public String getDough_size() {
		return dough_size;
	}
	public void setDough_size(String dough_size) {
		this.dough_size = dough_size;
	}
	public int getDough_qty() {
		return dough_qty;
	}
	public void setDough_qty(int dough_qty) {
		this.dough_qty = dough_qty;
	}
	public double getBill() {
		return bill;
	}
	public void setBill(double bill) {
		this.bill = bill;
	}
	
	
	

}
