package Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="doughnut_tbl")
public class doughnut_tbl 
{
	
	@Id
	private int dough_id;
		
	@Column(name="dough_name")
	private String dough_name;
	
	@Column(name="dough_price")
	private double dough_price;
	
	
	public int getDough_id() {
		return dough_id;
	}
	public void setDough_id(int dough_id) {
		this.dough_id = dough_id;
	}
	public String getDough_name() {
		return dough_name;
	}
	public void setDough_name(String dough_name) {
		this.dough_name = dough_name;
	}
	public double getDough_price() {
		return dough_price;
	}
	public void setDough_price(double dough_price) {
		this.dough_price = dough_price;
	}
	
	

}
