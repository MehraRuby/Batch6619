package ExceptionClasses;

@SuppressWarnings("serial")
public class CheckDoughQty extends InvalidQuantityException
{
	public CheckDoughQty(){super();}
}
