package ExceptionClasses;

@SuppressWarnings("serial")
public class  InvalidQuantityException extends Exception
{
	public InvalidQuantityException(){}
	
	public void checkQty(int x) throws InvalidQuantityException
	{
		if(x<1 || x>10)
			throw new InvalidQuantityException();		
	}
	
	public String toString() 
	{
		return "Quantity should be between 1-10";
	}
}