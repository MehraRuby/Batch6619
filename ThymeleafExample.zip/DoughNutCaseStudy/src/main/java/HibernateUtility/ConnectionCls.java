package HibernateUtility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ConnectionCls
{
	 static Configuration  cfg;
	 static SessionFactory  sf;
	 
	public static SessionFactory getSessionFactory()
	{
	cfg = new Configuration();
	sf = cfg.configure("connect.cfg.xml").buildSessionFactory();	
	return sf;
	}	
	
}
