package ServiceLayer;

import java.util.List;
import DAO.DoughNutDaoImpl;

import Entity.dough_order;
import Entity.doughnut_tbl;
import Entity.users;


public class DoughNutServiceImpl implements IDoughnutService
{
	
	public DoughNutDaoImpl dough;
	
	public DoughNutServiceImpl()
	{
		dough = new DoughNutDaoImpl();
	}
	
	
	public boolean validateUser(users u)
	{					
		return dough.validateUser(u);
	}

	public dough_order placeOrder(dough_order dord) {
		
		return null;
	}

	public List<doughnut_tbl> getDoughnuts() {		
		return dough.getDoughnuts();
	}	
	
	
	public Double getDoughPrice(int id) {
		return dough.getDoughPrice(id);
	}
	
}
