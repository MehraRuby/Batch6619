package ServiceLayer;

import java.util.List;

import org.springframework.stereotype.Service;

import Entity.dough_order;
import Entity.doughnut_tbl;
import Entity.users;


public interface IDoughnutService 
{
	boolean validateUser(users u);
	dough_order placeOrder(dough_order dord);
	List<doughnut_tbl>getDoughnuts();	
	Double getDoughPrice(int id);
}
