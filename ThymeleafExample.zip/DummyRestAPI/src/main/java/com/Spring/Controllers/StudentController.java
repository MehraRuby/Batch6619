package com.Spring.Controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

}
