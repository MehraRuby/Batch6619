package com.Spring.Course;

public class Course {

}
