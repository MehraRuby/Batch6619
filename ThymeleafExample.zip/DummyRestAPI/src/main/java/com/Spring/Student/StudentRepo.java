package com.Spring.Student;

public class StudentRepo {

}
