package mypack;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration  cfg = new Configuration();
		SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
		Session S = sf.openSession();
		
		S.getTransaction().begin();
		
		
		//Object states 
		/*  1: selecting a complete records */
		
		Criteria st = S.createCriteria(student.class);		
		List<student> LST = st.list();
		
			
		for(student s : LST)
		{
			System.out.println(s.getStid()+"    "+s.getStnm());
		}
		
		System.out.println("_____________________________");
		
		/*2: select partial records / partial state of an object */
		
		Query qry = S.createQuery("select s.stnm,s.phno from student s where s.crid=?");		
		 qry.setParameter(0, 5);
		 		 	
				List L =qry.list();
				
				System.out.println("Total Number Of Records : "+L.size());
				Iterator it = L.iterator();
		 		                		              
				while(it.hasNext())
				{
					Object o[] = (Object[])it.next();
		 
					System.out.println("Student Name : "+ o[0]+ "    Contact Number  : "+ o[1]);
		 			
				}
				
				System.out.println("______________________________________");
		
				
				
				
		/* 3: Partial object state with one field */
				
				Query qy = S.createQuery("select s.stnm from student s");		
				 qry.setParameter(0, 5);
				 		 	
						List<student> L1 =qy.list();
						
						System.out.println("Total Number Of Records : "+L1.size());
						Iterator it1 = L1.iterator();
				 		                		              
						while(it1.hasNext())
						{
							String nm = (String)it1.next();				 
							System.out.println("Student Name : "+ nm);
				 			
						}
						
						System.out.println("______________________________________");
				
	
						S.close();
						sf.close();
	
		
		        	  
    }
}
