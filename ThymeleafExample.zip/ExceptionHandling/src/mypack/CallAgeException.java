package mypack;
/*Display a exception message 
 * 			age ==0 - infant
 * 			age <=10  - kid
 *         age>=11 && age <18 - Not a valid voter
 *         >=18 - Valid voter
 */



class UserDefinedAgeException extends Exception
{
			String m;
			UserDefinedAgeException(){}
			UserDefinedAgeException(String msg)
			{
				this.m = msg;						
			}
			
			void age(int a) throws UserDefinedAgeException
			{
				if(a == 0)
					this.m = "Infant";
				else if(a>0 && a <=10)
					this.m="Kids";
				else if(a>=11 && a<18)
					this.m="Not a valid voter";
				else if(a>=18)
					this.m="Valid Voter";
				
				throw new UserDefinedAgeException(this.m);								
			}
			
			public String toString()
				{
					return this.m;
				}
}
public class CallAgeException 
{	
	public static void main(String... g)
	{
		
		 try
		 {
			 new UserDefinedAgeException().age(19);
			 
		 }
		 catch(UserDefinedAgeException e)
		 {
			 System.out.println(e);
		 }
	}
}
