package mypack;

class UserDefinedException extends Exception
{
	UserDefinedException(){}
	
	void value(int val) throws UserDefinedException
	{
		if(val<20)
				throw new UserDefinedException();
		else
			System.out.println("Valid value !");	
	}
	
	public String toString()
	{
		return "Invalid value ! It should be greater than 20.";
	}	
}

public class CallUserException
{
	public static void main(String... g)
	{
		UserDefinedException obj = new UserDefinedException();
		try
		{
			obj.value(89);
			obj.value(78);
			obj.value(34);
			obj.value(9);				
		}
		catch(UserDefinedException e)
		{
			System.out.println(e);
		}
	}
}
