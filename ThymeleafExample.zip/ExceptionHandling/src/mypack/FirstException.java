package mypack;

public class FirstException 
{
	public static void main(String... g)
	{
		int a=90,b=10,c;
		
		try
		{
			c = a/b;
			System.out.println("Result : "+c);									
		}
		catch(ArithmeticException e)
		{
			System.out.println("Child : "+ e);
		}
		catch(Exception e)
		{
			System.out.println("Base : "+ e);
		}
		finally
		{
			System.out.println("Always at exceuted ! ");
		}
		
	}
}
