package mypack;

public class NestedTry 
{
	public static void main(String... g)
	{
		int a=90,b=0,c;
		int arr[]=new int[1];
		
		try
		{
			try
					{
						c = a/b;
						System.out.println("Result : "+c);
					}
			catch(ArithmeticException e)
				{
				System.out.println("Division : "+ e);
				}
			
			arr[100] = 900;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
		System.out.println("Array : "+ e);
		}
		catch(Exception e)
		{
			System.out.println("Base : "+ e);
		}
		finally
		{
			System.out.println("Always at exceuted ! ");
		}
		
	}
}
