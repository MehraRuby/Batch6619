package mypack;

class Test1
{
		void display(int a)
		{
			if( a < 20)
				throw new ArrayIndexOutOfBoundsException();
			else
				System.out.println("Valid value ");
		}
	
}


public class THROWEXMAPLE 
{
	public static void main(String... g)
	{			
		try
		{
			Test1 obj = new Test1();
			obj.display(9);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
