package mypack;



class Test2
{
		void display(int a)throws ArithmeticException,ArrayIndexOutOfBoundsException
		{
			if( a < 20)
				throw new ArrayIndexOutOfBoundsException();
			
			else if( a >=20 && a<=50)
				throw new ArithmeticException();
			
			else
				System.out.println("Valid value ");
		}
	
}

public class THROWSEXAMPLE
{
	public static void main(String... g)
	{			
		try
		{
			Test2 obj = new Test2();
			obj.display(390);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}



