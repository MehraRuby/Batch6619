import java.io.*;
/*SequenceInputStream combines two or more other InputStream 's into one. 
 * First the SequenceInputStream will read all bytes from the first InputStream , 
 * then all bytes from the second InputStream .
 *  That is the reason it is called a SequenceInputStream, 
 *  since the InputStream instances are read in sequence.
*/
public class CombineFiles
{
	
	public static void main(String arg[])throws IOException
	{
	SequenceInputStream sin=new SequenceInputStream(new FileInputStream("d://todaydata//temp.txt"),new FileInputStream("d://todaydata//test.txt"));
	
	
	DataInputStream din=new DataInputStream(sin);
	
	FileOutputStream fout=new FileOutputStream("d://todaydata//tt.txt");
	DataOutputStream dout=new DataOutputStream(fout);
	
	
		
	String s=" ";
	while(s!=null)
	{
	s=din.readLine();
		if(s!=null)
			{	System.out.println(s);
				dout.writeBytes(s);
			}
			
	}
	din.close();
	sin.close();
	dout.flush();
	dout.close();
	}

}
