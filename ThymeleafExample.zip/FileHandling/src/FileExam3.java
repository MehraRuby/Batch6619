import java.io.*;

//character based

public class FileExam3
{
	public static void main(String... g) throws Exception
	{
		System.out.println("Enter a data: ");
		DataInputStream din=new DataInputStream(System.in);
		
		
		
		
		FileOutputStream fout=new FileOutputStream("d://todaydata//temp.txt");

		PrintStream  out=new PrintStream(fout);
		
		String s="";
		while(!s.equals("stop"))
			{
			s=din.readLine();
			out.println(s);
			}
			
		out.flush();

		out.close();
		
		
	}

}
