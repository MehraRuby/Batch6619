import java.io.*;

public class FileExample1 
{
	public static void main(String... g)
	{		
	try
		{
		String s;

		System.out.println("Enter a sentence to write in a file :");
		
		// reading a data from keyboard
		DataInputStream dis=new DataInputStream(System.in);
		s=dis.readLine();

		char ch[]=s.toCharArray();
		
		
		
		//write data in file from a buffer area where char array is stored
		
		FileWriter fout=new FileWriter("d://todaydata//test.txt");
		BufferedWriter bout = new  BufferedWriter (fout);		
			
		bout.write(ch,0,ch.length);
		bout.flush();
		bout.close();

		
		
		//reading
		

		FileReader fr=new FileReader("d://todaydata//test.txt");
		BufferedReader bis = new  BufferedReader (fr);
		
		
		char c[]=new char[ch.length];		
	
		bis.read(c,0,ch.length);
		bis.close();								
			
		
		
		String p = new String(c);				
		System.out.println("Data Read from file : \n\n" + p );

		}
	catch(Exception e) { System.out.println(e); }		
	}

	

}
