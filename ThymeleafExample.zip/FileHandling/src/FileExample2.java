import java.io.*;
import java.util.Scanner;


//bytes based
public class FileExample2 
{
	public static void main(String args[])throws IOException
	{
		Double d;
		

	System.out.println("Enter double value : ");
	Scanner sc= new Scanner(System.in);
	d = sc.nextDouble();
	
				
	FileOutputStream fout=new FileOutputStream("d://todaydata//tt.txt");
	DataOutputStream dout=new DataOutputStream(fout);

	
	String s="";
	
	DataInputStream din=new DataInputStream(System.in);

	
		s=din.readLine();
		//System.out.println(s);
		dout.writeUTF(s);
		dout.writeBytes(s);
		dout.writeChars(s);
		
	dout.writeDouble(d);
	dout.flush();
	dout.close();
	fout.close();
	
	
	
	//reading
	FileInputStream fin=new FileInputStream("d://todaydata//tt.txt");
	DataInputStream din1=new DataInputStream(fin);

	
	s="";

		System.out.println(s);
		
		String s1 = din1.readUTF();
		byte b  = din1.readByte();
		char ch = din1.readChar();
		System.out.println(s1);
		System.out.println(b);
		System.out.println(ch);
			
		
	
		double d1 = din1.readDouble();
		System.out.println(d1);
		din1.close();
		fin.close();
		}
	
	}
	
	
	//check again for data types

	
	


