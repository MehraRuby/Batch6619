
import java.io.*;
public class MyByteWriter 
{
	public static void main(String arg[])throws IOException
	{
	ByteArrayOutputStream fw=new ByteArrayOutputStream();
	
	//default constructor who takes default size,
	//you can also pass your own size in this 
	//constructor
	
	String s="India is a good country in the  world";
	
	byte ch[]=s.getBytes();
	
	for(int i=0;i<ch.length;i++)
			fw.write(ch[i]);
	
	
	
	
	//write bytes into a file
	fw.writeTo(new FileOutputStream("d://todaydata//rabri1.txt"));
	
	
	// read bytes from a file
	byte z[]=fw.toByteArray();	
	ByteArrayInputStream fr=new ByteArrayInputStream(z);
	
	int i=0;
	
	while((i=fr.read())!=-1)
			System.out.print((char)i);
	
	fw.close();
	fr.close();
	}

}
