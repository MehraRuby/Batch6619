package NIO;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashSet;
import java.util.Set;

public class FileChannelDemo {
   public static void main(String args[]) throws IOException
   {
      //append the content to existing file 
     // writeFileChannel(ByteBuffer.wrap("Java is a good programming language".getBytes()));
      
      //read the file
      readFileChannel();
      
   }
   
   
   public static void readFileChannel() throws IOException
   {
      RandomAccessFile r = new RandomAccessFile("d:/novel.txt","rw");
      
      
      FileChannel f = r.getChannel();
      ByteBuffer byteBuffer = ByteBuffer.allocate(80);
      
      Charset charset = Charset.forName("US-ASCII");
      
                    
      while (f.read(byteBuffer) > 0) 
      {
         byteBuffer.rewind();
         System.out.print(charset.decode(byteBuffer));
         byteBuffer.flip();
      }
            
      f.close();
      r.close();
   }
   
   
   
   
   public static void writeFileChannel(ByteBuffer byteBuffer)throws IOException
   {
      Set<StandardOpenOption> options = new HashSet<>();    
      
      
      options.add(StandardOpenOption.CREATE);
      options.add(StandardOpenOption.APPEND);
      
      
      Path path = Paths.get("d:/temp.txt");
      FileChannel fileChannel = FileChannel.open(path, options);
      
      
      fileChannel.write(byteBuffer);
      fileChannel.close();
   }
}