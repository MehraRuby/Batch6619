package NIO;
import java.io.IOException;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.file.FileSystem;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
public class PathDemo {
   public static void main(String[] args) throws IOException 
   {
      Path path = Paths.get("D:/file.txt");
      FileSystem fs =  path.getFileSystem();
      System.out.println(fs.toString());
      System.out.println("isAbsolute: "+path.isAbsolute());
      System.out.println("getFileName:"+path.getFileName());
      System.out.println(path.toAbsolutePath().toString());
      System.out.println(path.getRoot());
      System.out.println(path.getParent());
      System.out.println(path.getNameCount());
      System.out.println(path.getName(0));
  
      System.out.println(path.toString());
    
      Path realPath = path.toRealPath(LinkOption.NOFOLLOW_LINKS);
      System.out.println(realPath.toString());
      
   }
}