import java.io.*;

class emp implements Serializable
{
int a;
static int b;
String name;
transient int age;

	emp(String n, int ag, int a1,int h)
		{
		name = n;
		age = ag;
		a = a1;
		b = h;
		}
}

public class ObjectSerialDemo 
{
	public static void main(String... g) throws Exception
	{
		ObjectOutputStream OS;
		ObjectInputStream dis;
		
		//write object
		emp e1=new emp("My Data Center Information",90,5,20);
		
		

		FileOutputStream fout=new FileOutputStream("d://todaydata//PV.txt");
		
		OS=new ObjectOutputStream(fout);

		OS.writeObject(e1);
		OS.flush();
		OS.close();
		fout.close();
		
		
		
		//reading object 
		FileInputStream fin=new FileInputStream("d://todaydata//PV.txt");
		dis=new ObjectInputStream(fin);
		
		emp z=(emp)dis.readObject();

		System.out.println("Name="+z.name);
		System.out.println("age="+z.age);
		System.out.println("a="+z.a);
		System.out.println("b="+z.b);
		
		fin.close();		
		dis.close();
						
	}
}
