

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZIPFILEEXAMPLE 
{	
    public static void main( String[] args )
    {
    	byte[] buffer = new byte[1024];
    	ZipEntry ze;
    	int i=0;
    	FileInputStream in ;
    	
    	try{
 
    		FileOutputStream fos = new FileOutputStream("D://today//MyFile.zip");    		
    		
    		
    		ZipOutputStream zos = new ZipOutputStream(fos);
		
    		
    	String s[]={"abc.docx","rabri1.txt","PV.txt","DjangoDoc.pdf"};	
    	while(i<4)
    	{
    		
    	ze= new ZipEntry(s[i]);     	
    	zos.putNextEntry(ze);
    	
    	  
    		in= new FileInputStream("D://today//"+s[i]);
 
    		int len;
    		while ((len = in.read(buffer)) > 0) 
    			{
    				zos.write(buffer, 0, len);
    			}
    		
    		 
    		in.close();
    		
    		i++;
    		}
    	
    		zos.closeEntry(); 
    		//remember close it
    		zos.close(); 
    		
    		    	
    		System.out.println("Done");    
 
    	}catch(IOException ex){
    	   ex.printStackTrace();
    	}
    }
}

