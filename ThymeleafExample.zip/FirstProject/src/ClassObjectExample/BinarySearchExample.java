package ClassObjectExample;

public class BinarySearchExample 
{
	void sort(int arr[])
	{
		int temp;
		for(int i=0 ; i < arr.length ; i++)
		{
			for(int j=0; j < arr.length -  i - 1 ;j++)
			{
				if(arr[j] > arr[j+1])
				{
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}				
			}
		}
	}
	
	void display(int a[])
	{
		for (int x : a)
		{
			System.out.println(x);
		}
	}
	
	String  binSearch(int a[],int start,int end,int num)
	{
		int mid;
		mid = (start+end)/2;
		
		while(start<=end )
		{			
			if(a[mid] > num)
					end = mid -1;
			
			else if(a[mid] < num)
				   start = mid +1;
			
			else if(a[mid] == num)
				return "Value exist at "+ mid +" location.";
					
			mid = (start+end)/2;
		}
		
		if (start > end)	
			return "Not Exist";
		
		return "";			
	}
	
	
	String  recBinSearch(int a[],int start,int end,int num,int mid)
	{
		mid = (start+end)/2;
		
		if(a[mid] == num)
			
			return "Value exist at "+ mid +" location.";
		
		else if(a[mid] > num)
				end = mid -1;
		
		else if(a[mid] < num)
			   start = mid +1;
		
		if (start > end)	
			return "Not Exist";
		
		return recBinSearch(a,start,end,num,mid);				
	}
		
		
		
		public static void main(String... g)
		{
			int a[]= {34,54,87,98,12,100,23,84,4,1,79};
			int num = 12;
			BinarySearchExample obj = new BinarySearchExample();
			obj.sort(a);
			obj.display(a);
			
			System.out.println(obj.binSearch(a, 0, a.length-1, num));
			System.out.println(obj.recBinSearch(a, 0, a.length-1, num,0));
			
		}				
	}
	
	
	
	


