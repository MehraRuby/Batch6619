package ClassObjectExample;

public class CallByReference 
{
	int x;
	int z;
	
	CallByReference()
	{
		x=9;
		z=7;
	}
	
	void swap(CallByReference C1)
	{
		int temp;
		temp = C1.x;
		C1.x = C1.z;
		C1.z =temp;
		
	}
	
	void checkArray(int a[])
	{
		for(int i=0; i < a.length ;i++)
		{
			a[i] = a[i] * 10;
		}
	}
	
	
	public static void main(String... g)
	{
		
		int arr[]= {1,2,3,4,5};
		
		     CallByReference obj = new CallByReference();
		
			System.out.println("Before Swapping \nX: "+obj.x+"\nZ: "+obj.z);
			
			obj.swap(obj);
			
			System.out.println("After Swapping \nX: "+obj.x+"\nZ: "+obj.z);

			System.out.println("\nArray updated values are : ");
			
			
		     CallByReference ob ;
		     
		     ob = obj;  // cloning  obj (0x800) , ob = (0x800)    
		    		    
			ob.checkArray(arr);
			
			for(int q : arr)
			{
				System.out.println(q);
			}
		
			
			// Deep copy  + shallow copy - discussion + clone()
								
	}	
}
