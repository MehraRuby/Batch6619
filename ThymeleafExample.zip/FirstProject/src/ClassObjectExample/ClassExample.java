package ClassObjectExample;

public class ClassExample
{
	public static void main(String... g) 
	{
		Student st;  // reference variable
		st = new Student();
					
	//	st.stid=101;
		st.name="pooja";
		st.score = 100;
		Student.age = 30;
		
		st.setStid(101);
		
		System.out.println(st.stid+"  "+st.name+"  "+st.score+" "+Student.age);		
		
		
		Student s = new Student();
		
		
		// usage of predefined function
		try {
		Class C = Class.forName("java.lang.String");
		String str = (String)C.newInstance();
		str = "Hello";
		System.out.println(str);}catch(Exception e) {}
		
		
		
	}	
}
