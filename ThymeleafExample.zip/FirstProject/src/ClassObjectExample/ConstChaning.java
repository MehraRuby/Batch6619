package ClassObjectExample;


/* this - keyword
 * it represents the class object with in aclass
 * used to resolve name collosion of fields / state of a class
 * crete a constructor chaining  * * 
 * it should be a first statement in a constructor at the time of chaining
 */
public class ConstChaning 
{
	int score;
	
	ConstChaning()
	{
		this(90);
		System.out.println("default");		
	}
	
	ConstChaning(int score)
	{
		this("Java");
		System.out.println("integer");
		
		this.score = score;
			
	}
	
	ConstChaning(String nm)
	{
		System.out.println("string");
	}
	
	public static void main(String... g)
	{
			new ConstChaning();		
	}

}
