package ClassObjectExample;


/*
 *   constructor is a special method. It represents the class
 *   1: having a same name as class name;
 *   2: no return type
 *   3: can be private
 *   4: if private the all members of a class will be static.
 *   5: can be referred with 'this' keyword
 *   6: support constructor chaning concept
 *   7: Type: 
 *   			A - default constructor
 *             B - Parameterized Cons
 */
public class ConstructorExample 
{
	int score;
	String name;
	
	ConstructorExample()
	{
		score=90;
		name="adam";
	}
	ConstructorExample(int sc)
	{
		score = sc;
	}
	ConstructorExample(String nm)
	{
		name= nm;
	}
	
	ConstructorExample(int sc,String nm)
	{
		score =sc;
		name= nm;
	}
	
	void display()
	{
		System.out.println("Name : "+name+" \nScore : "+score);
	}
	
	public static void main(String... g)
	{
		new ConstructorExample().display();
		new ConstructorExample(101).display();
		new ConstructorExample("Mohan").display();
		new ConstructorExample(102,"Gautam").display();				
	}
	
}
