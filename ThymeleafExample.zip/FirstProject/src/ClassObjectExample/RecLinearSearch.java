package ClassObjectExample;

public class RecLinearSearch 
{	
	String linSearch(int arr[],int n,int i,String w)
	{
		if(arr[i] == n)
			return " Value exist at "+ i +" location";
		
		if (i >= arr.length-1)
		{
			return " Not Exist";
		}
		else
		{			
			i++;
			return linSearch(arr,n,i,w);
		}			
	}
		
		public static void main(String... g)
		{
			int a[]= {56,23,12,76,90,54,68,14,79,95};
			int n =680;
			
			System.out.println(new RecLinearSearch().linSearch(a, n,0,""));
										
		}	
}
