package ClassObjectExample;

public class RecTable 
{
	String table(int e,int i)
	{
		if(i > 10)
		{	
			return ""; 
		}
		else
		{
			System.out.println(e*i);
			i++;
			return table(e,i);
		}
			
	}
	
	
	// 0 1 1 2 3  5 8......... nth
	// a b x
	//    a b x
	String fib(int a,int b, int x,int n)
	{
		if(x > n)
				return "";
		else
		{
			if( x == 0)
			{
				System.out.print(a+"\t"+b+"\t");
			}
			
			x = a+b;
			
			if( x < n)
				System.out.print(x +"\t");
			
			
			a=b;
			b=x;
			return fib(a,b,x,n);			
		}
		
	}
	
		
	public static void main(String... g)
	{
		System.out.println(new RecTable().table(5, 1) );	
		new RecTable().fib(0, 1, 0, 100);
	}
	
}
