package ClassObjectExample;

/*   function which is calling itself
 *    no requirement of any loop statement
 *    syntax:
 *    				
 *    				func()
 *    						{
 *    									if ( termination condition)
 *    												return result value;
 *    									else
 *    										{
 *    												logic 
 *    												calling of func();
 *    										}     
 *    						}
 *    *   
 */
public class RecursiveFunction 
{		
	int  add(int temp,int i)
	{
		if (i > 10)
				return temp;
		else
		{
			temp = temp + i;
			i++;
			return add(temp,i);			
		}		
	}
	
	public static void main(String... g)
	{
		System.out.println("Sum : "+new RecursiveFunction().add(0, 1));	
	}	
}
