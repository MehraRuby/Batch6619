package ClassObjectExample;

public class Student
{
	// state  - fields 
	
	int stid;       // instance variables  - inside heap memory - when a constructor of a class is getting called.
	String name;
	int score;
	
	static int age;  // class variables - defines only one time - compliation process - retain till the end life cycle of main()
	
	
	// behavior - functions / methods - handles the entire flow of a class 	
	
	void setStid(int id)   // local variable
	{
		stid = id;
	}	
	
}
