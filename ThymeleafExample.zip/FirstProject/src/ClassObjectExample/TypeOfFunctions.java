package ClassObjectExample;

/* A : Non-static functions
 * 
 *  1: predefined 
 *  2: general function with local arguments  - call by value 
 *  3: general functions with object based arguments  - call by reference
 *  
 *   B: static function 
 *   C: recursive functions
 *   D: lambda functions
 *   E: generator function
 *   F: Special Function - Constructor
 *   
 *   
 */

public class TypeOfFunctions 
{
	// call by value
	
	int addition(int a,int b)  // a,b are arguments 
	{
		a = a*10;
		b = b*10;
		
		return a+b;		
	}
	
	public static void main(String... g)
	{
		int x=1,z=5;
		int s; 
		// 1 way
		TypeOfFunctions T1 = new TypeOfFunctions();
		s = T1.addition(9, 9); // parameters
		System.out.println(s);
		
		
		// 2 way
		TypeOfFunctions T2 ;
		T2 = new TypeOfFunctions();
		
		// 3 way
		
		s = new TypeOfFunctions().addition(7, 7);
		System.out.println(s);
		
		System.out.println(new TypeOfFunctions().addition(x, z)+ " "+x+ " "+z);
			
	}	
}
