package DynamicPolymorphism;


abstract class Polygon
{
	Polygon(){  System.out.println("default polygon");		}
	Polygon(String name){  System.out.println(name);		}
}

abstract class Shapes extends Polygon
{
	Shapes(){   
		super("Triangle");
		System.out.println("Shapes");	 }
}

class Circles extends Shapes
{
		Circles(){   System.out.println("Circles");	 }
}


public class CONSTABS
{
	public static void main(String... g)
	{
		new Circles();		
	}	
}
