package DynamicPolymorphism;

/*
 * 1:  Cannot instantiate the abstract class 
 * 2: can hold abstract method
 * 3: abstract method  cannot have a body
 * 4: can hold general method and have a body / logic
 * 5: always be inherited
 * 6: abstract method get overridding in chiuld classes.
*/

abstract class A2
{
	// general method
	void display()
	{
		System.out.println("display of a1 class");
	}
	
	// abstract method
	
	public abstract void setData();
	public abstract void getData();
	public abstract void setInfo();
	public abstract void getInfo();
}

// function overidding - copy of a fucntion is retain by abstract base class and different logic is hold by child classes 

class B2 extends A2
{

	@Override
	public void getData() {	
		System.out.println("getData");
	}

	@Override
	public void setInfo() {
		System.out.println("setInfo");
		
	}

	@Override
	public void getInfo() {
		System.out.println("getInfo");
		
	}

	@Override
	public void setData() {
		System.out.println("setData");
		
	}
	
}

public class CallAbs 
{
	public static void main(String... g)
	{
	//	A2 obj = new A2();  error
		
		B2 obj = new B2();
		obj.display();
		obj.getData();
		obj.setInfo();
				
	}
	

}
