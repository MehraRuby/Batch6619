package DynamicPolymorphism;

abstract class A3
{	
	// abstract method
	
	public abstract void setData();
	public abstract void getData();
	public abstract void setInfo();
	public abstract void getInfo();
}

abstract class Helper extends A3
{
	//override	
	public  void setData() {}
	public void getData() {}
	public void setInfo() {}
	public void getInfo() {}
}

class B3 extends Helper
{
	public void setInfo() 
	{
		System.out.println("setInfo");
	}
}

public class CallFewMethods 
{
	public static void main(String... g)
	{
		B3 obj = new B3();
		obj.setInfo();
	}	
}
