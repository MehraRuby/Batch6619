package DynamicPolymorphism;

/*/*
 * Write a program to create a class named shape. In this class we have three 
sub classes circle, triangle and square each class has two member function 
named draw () and erase (). Create these using polymorphism concepts * 
 * 
 */

abstract class Shape
{
	public abstract void draw();
		
	public abstract void erase();
		
}

class Circle extends Shape
{
	public void draw()
		{
		System.out.println("Draw of Circle class ! ");
		}
	public void erase()
		{
		System.out.println("Erase of Circle class ! ");
		}
}

class Triangle extends Shape
{
	public void draw()
		{
		System.out.println("Draw of Triangle class ! ");
		}
	public void erase()
		{
		System.out.println("Erase of Triangle class ! ");
		}
}

class Square extends Shape
{
	public void draw()
		{
		System.out.println("Draw of Square class ! ");
		}
	public void erase()
		{
		System.out.println("Erase of Square class ! ");
		}
}

public class CallShape
{
	public static void main(String... g)
	{
		new Circle().draw();
		new Triangle().erase();
		new Square().draw();
		new Square().erase();
	}
}
