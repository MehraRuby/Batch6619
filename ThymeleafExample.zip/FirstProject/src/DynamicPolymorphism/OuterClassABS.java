package DynamicPolymorphism;

class OuterClassABS 
{		
		abstract class InnerClass
		{
			public InnerClass(){}
			void display() { System.out.println("Display"); }
			
			public abstract void setInfo();								
		}
	
		class A2 extends InnerClass
		{			
			public A2(){}
			public void setInfo()
			{ System.out.println("SetInfo of A2");  }
			
		}
		
		static class STCLASS    //extends InnerClass
		{						
			public void setInfo()
			{ System.out.println("SetInfo of STCLASS");  }
		}
									
		public static void main(String... g)
		{
			OuterClassABS.A2 obj = new OuterClassABS().new A2();
			obj.display();
			obj.setInfo();	
			
			STCLASS ob = new STCLASS();
			ob.setInfo();
			
		}		
}
