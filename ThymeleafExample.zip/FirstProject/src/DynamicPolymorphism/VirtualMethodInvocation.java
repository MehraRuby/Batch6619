package DynamicPolymorphism;

class A1
{
	void display()
	{
		System.out.println("display os a1 class");
	}
}

class B1 extends A1
{
	void display()
	{
	//	super.display();
		System.out.println("display os b1 class");
	}
}

class C1 extends B1
{
	void display()
	{
	//	super.display(); // object of 1 level upper class
		System.out.println("display os c1 class");
	}
	
}

public class VirtualMethodInvocation 
{	
	
	void callFunc(A1 obj)  // virtual method invocation
	{
		
		if(obj instanceof A1 )
				System.out.println("obj is A1 instance");
		
		if(obj instanceof B1 )
			System.out.println("obj is B1 instance");
		
		if(obj instanceof C1 )
			System.out.println("obj is C1 instance");
		
				
		obj.display();
	}
	
	
	public static void main(String... g)
	{
	//	C1 obj = new C1();
	//	obj.display();
		
		VirtualMethodInvocation ob = new VirtualMethodInvocation();
		
	//	ob.callFunc(new A1());
	//ob.callFunc(new B1());  // upcasting 
		ob.callFunc(new C1());
		
	/*	A1 obj = new A1();
		obj= new B1();
		obj.display();*/
				
	}	
}
