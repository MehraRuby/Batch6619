package Encapsulation;

class CallStudent 
{
	public static void main(String... g)
	{
	// utilization relationship
		
		// nameless object
		
		new Student(101,"pooja").display();
										
	}	
}
