package Encapsulation;

public class Student 
{
	// instance variables
	int stid;
	String stnm;
	
	// class variable
	static int score;
	
	static
	{
		score=90;		
	}
	
	Student(){}
	
	Student(int id, String nm)  // id and nm - local variables
	{
		stid = id;
		stnm = nm;
	}
	
	// general function
	void display()
	{
		System.out.println(stid+"  "+stnm+"  "+score);
	}
	
}
