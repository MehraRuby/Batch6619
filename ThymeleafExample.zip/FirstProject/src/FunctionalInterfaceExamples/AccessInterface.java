package FunctionalInterfaceExamples;

interface Inter_9 
{
	class Internal
	{
		int val;
		
		Internal(){val =0; }
		
		void setVal(int v)
		{
			val = v;
		}
		
		int getVal()
		{
			return val;
		}	
	}	
}

class AccessInterface
{
	public static void main(String... g)
	{
		Inter_9.Internal obj = new Inter_9.Internal();
		obj.setVal(900);
		System.out.println(obj.getVal());
		
	}
}
