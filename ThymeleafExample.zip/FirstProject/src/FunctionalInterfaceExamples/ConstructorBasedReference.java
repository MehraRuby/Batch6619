package FunctionalInterfaceExamples;

@FunctionalInterface
interface Inter_3
{
	ConstructorBasedReference display(String s);
}


public class ConstructorBasedReference 
{
	ConstructorBasedReference(String d)
	{
		System.out.println("String is : "+d);
	}
	
	public static void main(String... g)
	{
		
		Inter_3 ref = ConstructorBasedReference::new;
			
		ref.display("Java Language");
														
	}
	
}
