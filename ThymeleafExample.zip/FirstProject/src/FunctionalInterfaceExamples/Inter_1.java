package FunctionalInterfaceExamples;

/* functioncal interface  - used for method references  or creating lamdba function*/

@FunctionalInterface
interface Inter_1 
{
	void display();	
}



// marker interface 
interface MARKER
{}