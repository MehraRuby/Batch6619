package FunctionalInterfaceExamples;

@FunctionalInterface
interface Inter_5
{
	boolean display(int a);
}


public class LAMBDAFUNCTION
{	
/*	String even_odd(int a)
	{
		return a % 2 ==0 ? "Even" : "Odd";
	}*/
	
	
	public static void main(String... g)
	{
		/*LAMBDAFUNCTION obj = new LAMBDAFUNCTION();
		System.out.println(obj.even_odd(30));	*/	
		
		
		// lambda function
		Inter_5 ref = (a) -> a%2==0 ;
		System.out.println(ref.display(90) ? "Even ": "Odd ");
				
	}
}


/*
 * lambda expression
 * 
 
		(parameters) -> {
								logic		
		};

*/