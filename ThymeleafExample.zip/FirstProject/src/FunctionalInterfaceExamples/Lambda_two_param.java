package FunctionalInterfaceExamples;

@FunctionalInterface
interface Inter_6
{
	int sum(int a,int b);
}


@FunctionalInterface
interface Inter_7
{
	void display(int... a);
}


public class Lambda_two_param
{
	public static void main(String... g)
	{
		Inter_6 ref =(x,z) -> x+z ;
		System.out.println("Sum : "+ref.sum(9, 9));
					
		Inter_7 ref1 = (z) -> {
											System.out.println("===========================================");
											System.out.println("Length : "+ z.length);
											for(int x : z)
											{
												System.out.println(x);
											}											
										};
		
										
	    ref1.display(1,2,3,4,5,6);
	    ref1.display(1,2);
	    ref1.display(1,2,3,4);
	    ref1.display();
		
	}
	
}
