package FunctionalInterfaceExamples;

@FunctionalInterface
interface Inter_2 
{
	void display();
}


@FunctionalInterface
interface SUM 
{
	int addition(int a,int b);
}




class ObjectReference
{
	void show()
	{
		System.out.println("Show");
	}
	
	int add(int x,int z)
	{
		return x+z;
	}
	
	public static void main(String... g)
	{
		ObjectReference obj = new ObjectReference();
				
			Inter_2 ref =  obj::show;
			
			ref.display();
			
			SUM refsum = obj::add;
			System.out.println("sum : "+refsum.addition(90, 90));
													
	}

}


/*

display = show
display =    0x800

*/