package FunctionalInterfaceExamples;

import java.util.ArrayList;

public class PassLambda 
{
	public static void main(String... g)
	{
		String arr[] = {"hope","happy","great","well","positive","best"};
		
	/*	for(String a : arr)
		{
			System.out.println(a);
		}*/
		
		ArrayList<String> A = new ArrayList<String>();
		
		// assign String object to arraylist class
		for(String x : arr)
		{
		A.add(x);	
		}
		
		// display arraylist objects
		
		A.forEach(m->
									{
					 						System.out.println(m);
									}
					    );
		
		/*
		 * lambda function passed as parameter to forEach()
				m->
								{
									System.out.println(m);
								}
		
		*/
									
	}	
}
