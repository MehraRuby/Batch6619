package FunctionalInterfaceExamples;

@FunctionalInterface
interface Inter_4
{
	int add(int a,int b);
}

class SUMVAL
{
	static int sum(int x,int z)
	{
		return x+z;
	}	
}


public class STATICBASEDREFERENCE 
{
	public static void main(String... g)
	{
		Inter_4 ref = SUMVAL::sum;
		int p = ref.add(9,9);
		System.out.println("Sum : "+p);	
		
	}	
}
