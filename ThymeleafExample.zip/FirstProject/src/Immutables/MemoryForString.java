package Immutables;

public class MemoryForString
{
	public static void main(String... g)
	{
		String str1="Java";
		String str2 = new String("Java");
		
		String str3 = new String("jAvA");
		
		String str4 = new String("Java");
		
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str3.hashCode());
		System.out.println(str4.hashCode());
		
		
		// equals() checks the values
		if(str1.equals(str2))
				System.out.println("Equals");
		else
				System.out.println("Not Equals");
		
		
		if(str2.equals(str3))
				System.out.println("Equals");
		else
				System.out.println("Not Equals");
			
		// == checks the type / memory locations
		
		if(str1 == str2)
			System.out.println("Equals");
	else
			System.out.println("Not Equals");
	
	
	if(str2 == str3)
			System.out.println("Equals");
	else
			System.out.println("Not Equals");
	
	if(str2 == str4)
		System.out.println("Equals");
else
		System.out.println("Not Equals");
		
		
	}	
}
