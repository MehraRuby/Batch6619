package Immutables;

public class StringFunctions 
{
	public static void main(String... g)
	{
			String str1 = "Python and Java is a programming language and good resource tool support API and Web Services.";
			
			String str2 =" Java ";
			String str3 = " Language ";
			
			String str4="";
			// reverse a string and find palindrome
			for (int i = str3.length()-1 ; i >=0 ; i--)
			{
				str4 = str4 + str3.charAt(i);				
			}
			
			System.out.println("Reverse string : "+str4);
			
			if(str4.equals(str3))
				System.out.println("Palindrome String");
			else 
				System.out.println("Not A Palindrome String");
			
			String str5 = str3.concat(str4);
			System.out.println(str5);
			
			System.out.println(str1.contains("maths"));
			byte arr[] = str1.getBytes();
			for(int i=0;i<arr.length;i++)
			{
				System.out.print(arr[i]+"\t");
			}
			
			System.out.println();
			System.out.println(str1.indexOf("and"));
			System.out.println(str1.indexOf("and",20));
			System.out.println(str1.lastIndexOf("and"));
			System.out.println(str1.lastIndexOf("and",45));
			
			str5 = str1.replaceAll("and", "MATHS");
			System.out.println(str5);
			
			str5="SE10101";
			
			System.out.println(str5.substring(0,str5.indexOf('E')+1));
			System.out.println(str5.substring(str5.indexOf('E')+1 , str5.length()-1));
			
			char ch[] = str1.toCharArray();
			for (char c : ch)
			{
				System.out.print(c+" ");
			}		
			
			System.out.println();
			String s = String.valueOf(ch);
			System.out.println(s);
			
			
			
	}
}
