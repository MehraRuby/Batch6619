package Inheritance;


class A
{
	protected void setData_1()
	{
		System.out.println("setData_1");
	}
		
	public void setData_2()
	{
		System.out.println("setData_2");
		setData_3();
	}
	
	private void setData_3()
	{
		System.out.println("setData_3");
	}
	
}

class B extends A
{
	B()
	{
		System.out.println("b default ");
	}
}

class C 
{
	private C(){}
	
	static void setData_4()
	{
		System.out.println("setData_4");
	}
		
}


public class Function_Single_Inheri 
{
	public static void main(String...  g)
	{
		B obj = new B();
		obj.setData_1();
		obj.setData_2();
		
		//C ob = new C();   because it is private constructor
	//	ob.setData_4();
		
		C.setData_4();		
	}
}
