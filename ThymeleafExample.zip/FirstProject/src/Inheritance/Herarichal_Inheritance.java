package Inheritance;

class A4
{
	void display_a4()
	{
		System.out.println("display by a4");
	}
	
}

class B4 extends A4
{
	void display_b4()
	{
		System.out.println("display by b4");
	}
	
}

class C4 extends A4
{
	void display_c4()
	{
		System.out.println("display by c4");
	}
	
}

public class Herarichal_Inheritance 
{
public static void main(String... g)
	{
		B4 ob = new B4();
		C4 oc = new C4();
		
		ob.display_a4();
		ob.display_b4();
		
		
		ob.display_a4();
		oc.display_c4();
	}
}
