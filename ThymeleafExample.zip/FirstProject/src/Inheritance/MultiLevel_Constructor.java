package Inheritance;


class A3  // super class
{
		A3()
		{  System.out.println("default of a3"); }	
		
		A3(String s)
		{
			System.out.println("String param get called");			
		}
		A3(int s)
		{
			System.out.println("integer param get called");		
		}
		
}

class B3 extends A3
{
	B3()
	{  
		//super("Hello");	
		super(90);
		System.out.println("default of b3"); }		
	
	B3(int s)
	{
		super("Hello");
		System.out.println("integer param get called for b3");		
	}
	
	
}

class C3 extends B3
{
	C3()	
	{ 
		super(90);
		System.out.println("default of c3"); }		
}


public class MultiLevel_Constructor 
{
	public static void main(String... g)
	{
		new C3();
	}
}
