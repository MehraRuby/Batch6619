package Inheritance;

class A2  // super class
{
	void display_a2()
	{
		System.out.println("display_a2");
	}
	
}

class B2 extends A2 // b2 is a super class for c2
{
	void display_b2()
	{
		System.out.println("display_b2");
	}
}

class C2 extends B2
{
	void display_c2()
	{
		System.out.println("display_c2");
	}
}

public class MutliLevel_Inheritance
{
	public static void main(String... g)
	{
		C2 obj = new C2();
		obj.display_a2();
		obj.display_b2();
		obj.display_c2();
	}	
}
