package Inheritance;

class A1
{
	private int x;
	protected int z;
	public int p;
	
	
	public static int m;
	private static int d;
	protected static int e;
	
	static
	{
		m=1;
		d=2;
		e=3;		
	}

	
}

class B1 extends A1
{
	protected static final  float PIE=3.14F;	
	
	B1()
	{
		z=100;
		p=101;
		
	}
	
	void display()
	{
	//	System.out.println(x);
		System.out.println(z);
		System.out.println(p);	
		System.out.println(m);
	//	System.out.println(d);
		System.out.println(e);
		System.out.println(PIE);
		
		
	}
}

public class SingleInheritance 
{
	public static void main(String... g)
	{		
		B1 obj = new B1();			
					
		System.out.println(B1.e);
		System.out.println(obj.p);
		System.out.println(obj.z);
				
	}	
}
