package InterfacesExamples;

public class A1 
{

}
