package InterfacesExamples;

/*
 *   1: interface keyword is used
 *   2: no object for interfaces
 *   3: implements with a class
 *   4: contain static final constant variables
 *   5: methods can be public abstract (by default), does not have body
 *   6: in java 8 - new introduction are 
 *   						- now , can create 'default' methods with body / logic
 *   						- can hold static methods
 *  						
 *  7: interface with only  one abstract method , is called Functional Interface
 *  8: interface with no method , is called Marker Interface
 *  9: with functional interface , we can pass method reference
 *  								- via object
 *  								- via static method
 *  								- via constructor
 *  *  
 *  10: functional interface can be used to pass lambda functions
 *  11: interface can hold a internal class declarations
 *  12: interface can extends another interface
 *  13: interface can implements multiple inheritance concept 						
 */

interface Inter1 
{	
	public static final float PIE = 3.14F;
	
	void showData();  // this abstract method get override in a class
	
	default void commonFunc()
	{
		System.out.println("Common Logic for all child  classes.....  ");		
	}
	
	static void setData()
	{
		System.out.println("Static method of interfaces ");	
	}	
}
