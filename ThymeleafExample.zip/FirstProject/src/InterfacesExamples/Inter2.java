package InterfacesExamples;

public interface Inter2
{
	void getData();
	void enterData();
}
