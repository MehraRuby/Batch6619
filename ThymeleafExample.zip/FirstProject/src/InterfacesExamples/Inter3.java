package InterfacesExamples;

public interface Inter3 extends Inter1,Inter2  // implements multiple inheritance here
{
	void pushData();
}
