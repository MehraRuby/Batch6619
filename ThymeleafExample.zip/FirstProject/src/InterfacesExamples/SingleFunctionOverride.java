package InterfacesExamples;

interface IN_1
{
	void show();
}

interface IN_2
{
	void data();
}

interface IN_3
{
void value();
}

interface IN_4 extends IN_1, IN_2,IN_3
{
void expression();
}

abstract class ABS implements IN_4
{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void data() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void value() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void expression() {
		// TODO Auto-generated method stub
		
	}

}

public class SingleFunctionOverride extends ABS
{
	@Override
	public void expression() 
	{
	System.out.println("expression");		
	}
}
