package InterfacesExamples;

public class UseInterface   extends A1 implements Inter1,Inter2
{
	public void showData()
	{
		System.out.println("showData.....");
	}

	void ZZ()
	{
		UseInterface obj = new UseInterface();
		
		obj.commonFunc();
		
		System.out.println("PIE: "+ Inter1.PIE);
		Inter1.setData();
		
		obj.showData();
	}
	
	public static void main(String... g)
	{	
		new UseInterface().ZZ();
				
	}

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enterData() {
		// TODO Auto-generated method stub
		
	}
	
}
