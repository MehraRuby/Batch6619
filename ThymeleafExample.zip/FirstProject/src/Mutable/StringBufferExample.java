package Mutable;

public class StringBufferExample 
{
public static void main(String... g)
	{
			StringBuffer str1 = new StringBuffer("Java");
			StringBuffer str2 = new StringBuffer(" Java Programming Language");
			
			System.out.println(str1.hashCode());
			System.out.println(str2.hashCode());		
			
			System.out.println("Before Length : "+str1.length());
			
			str1.append(str2);
			
			System.out.println("After Length : "+str1.length());
			
			System.out.println("Total Capacity : "+str1.capacity());
			
		//	System.out.println(str1);
			
			str1.trimToSize();
			
			System.out.println("After Trim to Size  Capacity : "+str1.capacity());
			
			str1.append(1001);
			
			System.out.println(str1);
			
			str1.trimToSize();
			
			System.out.println("After Trim to Size  Capacity : "+str1.capacity());
			
			str1.ensureCapacity(10);  // minimum capacity that should be there in buffer area
	
			System.out.println(str1.indexOf(" Java"));
			str1.setCharAt(4, 'P');
			System.out.println(str1);
			
			str1.reverse();
			System.out.println(str1);
			
			String st = str1.toString();
			System.out.println(st);
			
			str1.insert(3, "HELLO");
			System.out.println(str1);
			
			System.out.println(str1.substring(3, 10));

	}
}
