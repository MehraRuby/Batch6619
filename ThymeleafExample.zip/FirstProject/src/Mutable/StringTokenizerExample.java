package Mutable;

import java.util.StringTokenizer;
import java.util.StringJoiner;

public class StringTokenizerExample
{
	public static void main(String... g)
	{
	String str = " this is a test document. Java Programming language.";
		
	StringTokenizer st = new StringTokenizer(str," ");
	while(st.hasMoreElements())
		{
		String s = (String)st.nextElement();
		System.out.println(s);
		}
	
	String str1[] = {"happy","glad","groom","spend","blessed","clam","positive"};
	
	StringJoiner sj = new StringJoiner("$"   ,  " ( "   ,  " ) "   );
	
	for(String s : str1)
	{
		sj.add(s);
	}
	
	System.out.println(sj);
	
	}	
}
