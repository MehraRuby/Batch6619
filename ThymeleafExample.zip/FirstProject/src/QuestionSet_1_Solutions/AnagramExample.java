package QuestionSet_1_Solutions;

public class AnagramExample
{
	String[] splitSentence(String st)
	{
			return st.split(" ");				
	}
	
	
	int check(String str1,String str2)
	{
		char ch1,ch2;
		int count=0;
		for(int i=0 ; i < str1.length() ;i++)
		{
			ch1 = str1.charAt(i);
			
			for(int j=0; j < str2.length() ;j++)
			{
				ch2 = str2.charAt(j);
				
				if(ch1 == ch2)
					count++;				
			}
		}
		
		if(count == str1.length())
			return 1;
		
		return 0;			
	}
	
	
	public static void main(String... g)
	{
		AnagramExample obj = new AnagramExample();
		
		String str = "dog keep plate bread cat god peek listen beard act slient petal";
			
		String a[] = obj.splitSentence(str);
		
		int len = a.length;
		int flag=0;
		
		for(int i=0 ; i < len ;i++)
		{							
			for(int j = i+1 ; j < len ;j++)
			{
				if (a[i].length() == a[j].length())
				{				
					flag = obj.check(a[i],a[j]);
		
						if(flag == 1)
							System.out.println(a[i]+"  -  "+ a[j]);										
				}
			}
					
		}  // outer for closed
		
	}	
}
