package QuestionSet_1_Solutions;

import java.util.Scanner;

public class BinaryAddition 
{
	public static void main(String... g)
	{
		long a,b;
		int r1,r2,c=0,s[] = new int [10],i=0;
				
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter value 1: ");
		a = sc.nextLong();
		
		System.out.println("Enter value 2: ");
		b = sc.nextLong();
							
		while(a!=0 || b!=0)
		{			
		r1 = (int)a % 10;   
		r2 = (int)b % 10;

		s[i++] = (r1+r2+c)%2;	
		c = (r1+r2+c)/2;
	//	System.out.println(s[i]+" "+c);
	//		i++;
		a = a/10;
		b = b/10;			
		}
			
		if(c>=1)
		{
			s[i] = c;
		}
		
		for( ; i>=0 ;i--)
		{
			System.out.print(s[i]);
		}
								
	}
}
