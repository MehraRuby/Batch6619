package QuestionSet_1_Solutions;

public class Find_Replace_Example
{	
	public static void main(String... g)
	{
		String str = "          Java is a programming language and having frameworks.            ";
	
		String find="language".trim();
		String replace="SCIENCE".trim();
		
		str = str.trim();
		String st[] = str.split(" ");
		
		int len = st.length;
		for(int i=0 ; i < len ; i++)
		{							
			if(st[i].equals(find))
				st[i]=replace;					
		}			
		
		String s = String.join(" ", st);
		System.out.println(s);	
				
	}	
}
