package QuestionSet_1_Solutions;

public class LargestPalindrome 
{
	
	int check(String str3)
	{			
		String str4="";		
		for (int i = str3.length()-1 ; i >=0 ; i--)
		{
			str4 = str4 + str3.charAt(i);				
		}
					
		if(str4.equals(str3))
			return 1;
		
		return 0;
	}
	

	public static void main(String... g)
	{
		
		LargestPalindrome  obj = new LargestPalindrome();
		
	//String str = "Madam told Ana to collect 12321 count of radar and check its level for mapping on 02/02/2020.";
	String str1 = "aabaa123321aabaa";
	String output ="",result="";
	int flag=0,n=0,temp=0;
	
	for(int i=0 ; i < str1.length() ; i++ )
	{
		for(int j = n ;j <=i ; j++ )
		{
			output = output + str1.charAt(j);
		}
		
		flag=obj.check(output);
		if(flag == 1)
		{
			n=i;
			System.out.println(output);
			if(temp < output.length())
			{
				temp = output.length();
				result=output;
			}			
		}		
		output="";
	}
	
	System.out.println("Largest Palindrome subString is : "+result);
		
	}
}
