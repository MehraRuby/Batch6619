package QuestionSet_1_Solutions;

import java.util.Scanner;

public class Palindrome 
{
	String check(String str3)
	{			
		String str4="";
		// reverse a string and find palindrome
		for (int i = str3.length()-1 ; i >=0 ; i--)
		{
			str4 = str4 + str3.charAt(i);				
		}
					
		if(str4.equals(str3))
			return "Palindrome String";
		
		return "Not A Palindrome String";
	}
	
	public static void main(String... g)
	{
		String str="";
			
		Scanner sc = new Scanner(System.in);
		
		System.out.println("\nEnter a string : ");
		str = sc.next();
		
		System.out.println(new Palindrome().check(str));
				
		
	/*	System.out.println("\nEnter a string : ");
		str = sc.nextLine();
		
		System.out.println(str); */
			
	}
}
