package QuestionSet_1_Solutions;

/* Panagram - all characters except white spaces */

public class PanagramExample 
{
	String check(String str)
	{
		char ch ;
		
		str = str.toLowerCase();
		
		for(int i = 0 ; i < str.length() ;i++)
		{
			ch = str.charAt(i);
			if( ! ((ch >= 'a' && ch <= 'z') || (ch==' ')))
			{
					return "Not a Panagram";
			}			
			
		}
		
	return "Panagram";			
	}
	
	public static void main(String... g)
	{		
		String st = "this is a test document";
		
		System.out.println(new PanagramExample().check(st) );				
	}
		
}
