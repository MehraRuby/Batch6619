package STATICIMPORT;

import static java.lang.System.*;
import static STATICIMPORT.Example.*;

public class STAT_IMPORT 
{
public static void main(String... g)
	{
		out.println("Hello");
		err.println("Error");
		
		System.out.println(score);
		display();		
	}		
}
