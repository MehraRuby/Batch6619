package STATICIMPORT;

class Example
{
	public static int score;
	static
	{
		score=90;
	}
	
	private Example() {}
	
	public static void display()
	{
		System.out.println("Display "+score);
	}	
}

public class SingletonPattern 
{
	public static void main(String... g)
	{
		//Example obj = new Example();  - because of private access, we cannot create an object of a class 
		
		System.out.println("Score: "+Example.score);
		Example.display();
	}

}
