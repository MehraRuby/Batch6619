package STATICIMPORT;


/*
 * toString() - Object
 * 
 * 
 * 
 */
class Student 
{
	int stid;
	String nm;
	
	Student(int id,String n)
	{
		stid =id;
		nm =n;
	}
		
	// to create a proper msg output for an object , we will override toString() of Object class
	
	public String toString()
	{
		return "Student Detail:\nStid : "+stid+"\nStudent Name : "+nm;
	}
	
}

class TOSTRINGFUNC
{
public static void main(String... g)
	{
	
	Student obj = new Student(101,"Pooja");
	System.out.println(obj);
	
	}
	
}



