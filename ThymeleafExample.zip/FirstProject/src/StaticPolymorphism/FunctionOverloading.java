package StaticPolymorphism;

/* function overloading - 
 * 				same methods name
 * 				may or may not return types , that are same / different
 * 			    argument list - must be different
 * 			Ex -    void sum(int a,int b)
 * 						void sum(String a,String b)
 * * 
 */
public class FunctionOverloading 
{
	int sum(int a,int b)  // arguments
	{
		return a+b;
	}
	
	String sum(String a,String b)
	{
		return a.concat(b);
	}
		
	int sum(int a,int b,int c)
	{
		return a+b+c;
	}
	
	public static void main(String... g)
	{
		FunctionOverloading obj = new FunctionOverloading();
		System.out.println(obj.sum(8, 9));  // parameters
		System.out.println(obj.sum(8, 9,7));
		System.out.println(obj.sum("Java"," Language"));
	}
	
}
