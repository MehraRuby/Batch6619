package StaticPolymorphism;

public class MainOverloading 
{
	String main(String n)
	{
	 return n;		
	}
	
	int main(int a,int b)
	{
		return a+b;
	}
	
	void main()
	{
		System.out.println("void main");
	}
	
	public static int main(int a,int b,int c,int d)
	{
		return a+b+c+d;
	}
	
	public static void main(String... g)
	{
		MainOverloading obj = new MainOverloading();
		obj.main();
		System.out.println(obj.main("Hello"));
		System.out.println(obj.main(3,4));
		System.out.println(MainOverloading.main(1, 2, 3, 4));
			
	}

}
