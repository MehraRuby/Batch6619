package TypeOfClasses;

public class MethodBasedClass
{
	private int age ;
	
	void display()
	{
			class InnerClass
			{
				int score;
				
				void setData(int sc,int a)
				{
					score = sc;
					age = a;
				}
				int getData()
				{
					return score;
				}		
								
			}
			
			InnerClass obj = new InnerClass();
			obj.setData(100,90);
			System.out.println(obj.getData());
		
	}
	
	
	public static void main(String... g)
	{
		new MethodBasedClass().display();
	}	
}
