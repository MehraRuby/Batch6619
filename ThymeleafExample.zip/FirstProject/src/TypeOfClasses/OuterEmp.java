package TypeOfClasses;

class OuterClass
{
	private int age;
	
	//member based class / nested class
		class InnerClass // object life cycle of inner class totally depends on outer class object
				{
					int score;
					
					void setData(int sc,int a)
					{
						score = sc;
						age = a;
					}
					int getData()
					{
						return score;
					}		
				}		
}

class OuterEmp
{
	public static void main(String... g)
	{
		//1 way
		OuterClass obj = new OuterClass();
		OuterClass.InnerClass I = obj.new InnerClass();
		I.setData(100,90);
		System.out.println(I.getData());
		
		//2 way 
		
		OuterClass.InnerClass I2 = new OuterClass().new InnerClass();
		I.setData(100,90);
		System.out.println(I.getData());
		
		// 3 way
		
		new OuterClass().new InnerClass().setData(120, 78);
		
		
	}
}



