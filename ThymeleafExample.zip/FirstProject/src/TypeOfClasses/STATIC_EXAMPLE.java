package TypeOfClasses;

/*  1: static is a keyword
 *   2: static members can be declared and resource get assigned at the time of compilation.
 *   3: static variable can also be called as class variables
 *   4: static members get declared in stack memory
 *   5: static variables' default value can be assigned in static block
 *   6: static block get called before default constructor
 *   7: Class name is required to call static members
 *   8: if any concrete class is having private default constructor then , all the members of that class would be static. This
 *   type of declaration comes under Singleton pattern
 *   9: static variable can be shared among multiple objects of a class.
 *   10: static variables can retain their values.
 */

public class STATIC_EXAMPLE 
{
	static int x;
	static 
	{
		x =90;	
		System.out.println("static block");
	}
		
	STATIC_EXAMPLE()
	{
		System.out.println("default const");
	}
	
	void value()
	{		
		System.out.println("X: "+x);		
		x++;
	}
		
		
	public static void main(String[] args) 
	{
	 new STATIC_EXAMPLE().value();
	 new STATIC_EXAMPLE().value();
	 new STATIC_EXAMPLE().value();
	 new STATIC_EXAMPLE().value();
	 new STATIC_EXAMPLE().value();
	}

}
