package TypeOfClasses;

public class StaticClassExample 
{
	private int x;
	static int a;
		
	static class InnerClass
	{
		int s;
		static int z;
		
			InnerClass()
			{
				a=90;
				// x=89;  non static member cannot get accessed in static class
				s=90;
				z=78;				
			}
			
			void display()
			{
				System.out.println("Non-Static Method");				
			}
			
			static void getData()
			{
				System.out.println("getdata get called....");
			}							
	}
	
	public static void main(String... g)
	{
		StaticClassExample.InnerClass I = new StaticClassExample.InnerClass();
		I.display();
		
		StaticClassExample.InnerClass.getData();
		
	}	
}
