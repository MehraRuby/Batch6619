package AutoWireExample;

import org.springframework.beans.factory.annotation.Autowired;

public class Department 
{	
	
	@Autowired
	private Employee emp;	
	
	private int departid;
		
	Department()
		{
		System.out.println("Department is created");			  
		}
		
	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}


	public int getDepartid() {
		return departid;
	}

	public void setDepartid(int departid) {
		this.departid = departid;
	}

	void print()
			{
			System.out.println("Hello Department");  
			}
	
	
	void display()
			{  
	    	print();  
	    	emp.print();  
			}
	
}
