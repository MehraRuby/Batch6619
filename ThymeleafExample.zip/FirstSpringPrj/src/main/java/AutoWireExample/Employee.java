package AutoWireExample;

public class Employee
{
	Employee()
		{
			System.out.println("Employee is created");
		}
		
	void print()
		{
			System.out.println("Hello Employee");
		}  	
}
