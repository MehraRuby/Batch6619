package DependencyInjection;
import java.util.List; 
import org.springframework.context.ApplicationContext; 
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Test 
		{
		public static void main(String[] args)
				{
					ApplicationContext context = new ClassPathXmlApplicationContext("DependencyInjection/DI_Collection.xml");   
					Student student = (Student) context.getBean("student"); 
					
					System.out.println("Student info: "); 
					System.out.println("Name: " + student.getName()); 
					System.out.println("RollNo: " + student.getRollNo()); 
					System.out.println("Class: " + student.getClassName()); 
					
					List<Address> SAL = student.getAddress(); 
					
					int c= 1;  
					for (Address studentAddress : SAL ) 
							{
							System.out.println("Student Address " + c + " : "); 
							System.out.println("Address Line: "+studentAddress.getAddLine()); 
							System.out.println("City: " + studentAddress.getCity());
							System.out.println("State: " + studentAddress.getState()); 
							System.out.println("Country: " + studentAddress.getCountry()); 
							c++; 
							}
					
					
				}
	
		}
	
	