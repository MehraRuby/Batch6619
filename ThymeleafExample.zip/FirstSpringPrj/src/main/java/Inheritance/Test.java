package Inheritance;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 
public class Test 
	{
	public static void main(String[] args) 
			{
			//Get ApplicationContext using spring configuration file.
		
		
  ApplicationContext c = new ClassPathXmlApplicationContext("Inheritance/home.xml");
 
  			//Get HelloWorld bean object from ApplicationContext instance.
  
  
  HelloWorld helloWorld = (HelloWorld) c.getBean("helloWorld");
  
 
  //Process HelloWorld Object.
  
  
  System.out.println("HelloWorld bean properties: ");
  System.out.println("Hello " + helloWorld.getMsg1());
  System.out.println("Hello " + helloWorld.getMsg2());
 
  //Get HelloJava bean object from ApplicationContext instance.  
  
  
  HelloJava helloJava = (HelloJava) c.getBean("helloJava");
 
  //Process HelloJava Object.
  
    
  System.out.println("HelloJava bean properties: ");
  System.out.println("Hello " + helloJava.getMsg1()); // calling function of parent bean class
  System.out.println("Hello " + helloJava.getMsg2());
  System.out.println("Hello " + helloJava.getMsg3());
  
 } 
}
