package Inheritance;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test_Template 
	{ 
	public static void main(String[] args) 
			{
			//
			
			ApplicationContext C = new ClassPathXmlApplicationContext("Inheritance/template.xml");
			
			
			HelloWorld HW= (HelloWorld)C.getBean("helloWorld");
			
			
			
			System.out.println("HelloWorld bean properties: ");
			
			System.out.println("Hello " + HW.getMsg1()); 			
			System.out.println("Hello " + HW.getMsg2());  
			
			
			
			
			
			
			
			HelloJava HJ = (HelloJava)C.getBean("helloJava"); 
			
			System.out.println("HelloJava bean properties: "); 
			System.out.println("Hello " + HJ.getMsg1()); // calling base template bean class method
			System.out.println("Hello " + HJ.getMsg2()); 
			}
	}
	