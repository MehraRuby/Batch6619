package mypack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("mypack/DI_Collection.xml");  
    	
		Student s= (Student) context.getBean("obj"); 
		System.out.println(s.getRollNo());
		System.out.println(s.getName());
		System.out.println(s.getClassName());
		
		Employee e= (Employee) context.getBean("emp"); 
		
		System.out.println(e.getEm());
		System.out.println(e.getName());
	
					
    }
}
