package mypack;

public class Department 
{
	private String depart;
	private String deptname;
	private String msg1;
	
	public String getDepart() {
		return depart;
	}
	public void setDepartid(String departid) {
		this.depart = departid;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public String getMsg1() {
		return msg1;
	}
	public void setMsg1(String msg1) {
		this.msg1 = msg1;
	}
			
}
