package mypack;

public class Employee 
{
	private String em;
	private String name;
	private String msg1;
	
	public String getEm() {
		return em;
	}
	public void setEm(String empid) {
		this.em = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMsg1() {
		return msg1;
	}
	public void setMsg1(String msg1) {
		this.msg1 = msg1;
	}
	
}
