package mypack;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

//POJO

public class Student implements InitializingBean, DisposableBean 
{
	private String name; 
	private String rollNo;
	private String className;	
	
	public String getName() 
			{
			return name; 
			}
	public void setName(String name)
			{
			this.name = name;
			}
	public String getRollNo() 
			{
			return rollNo; 
			} 
	public void setRollNo(String rollNo) 
			{
			this.rollNo = rollNo;
			}
	public String getClassName()
			{
			return className;
			}
	public void setClassName(String className) 
			{
			this.className = className; 
			}
	
	public void afterPropertiesSet() throws Exception 
	{
		System.out.println("after properties set get called....");		
		setRollNo("121");
	}
	
	public void init()
	{
		System.out.println("Init get called....");
	}
	
	public void destroy()
	{
		System.out.println("destroy");
	}
	
	}
