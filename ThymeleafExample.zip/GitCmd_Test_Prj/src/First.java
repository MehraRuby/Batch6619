
public class First {
	public void display1() {
		System.out.println("Hello");
	}

	public void display2() {
		System.out.println("Hello");
	}

}
