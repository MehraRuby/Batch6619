
public class Second {
	public void display1() {
		System.out.println("Hello");
	}

	public void display2() {
		System.out.println("Hello");
	}

	public void display3() {
		System.out.println("Hello");
	}
}
