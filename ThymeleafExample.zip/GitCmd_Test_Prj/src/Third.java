public class Third {
    public void display1() {
        System.out.println("Hello");
    }
}
