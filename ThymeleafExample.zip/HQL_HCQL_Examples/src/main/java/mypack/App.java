package mypack;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class App 
{
	//HQL 
	
    public static void main( String[] args )
    {
                   
		 Configuration  cfg = new Configuration();
		 SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
			Session S = sf.openSession();
			
				S.getTransaction().begin();
				
				// HCQL
				
				Criteria st = S.createCriteria(student.class);
				Criterion cr = Restrictions.between("marks", 50, 85);
					
				// arrange all the records in descending manner
				st.add(cr);
											
				List<student> LST = st.list();
				LST.forEach(m -> {
				System.out.println(m.getStdid()+"   "+m.getStnm()+"     "+m.getMarks()+"     "+m.getCrid());
				});
        
              
    }              
}
