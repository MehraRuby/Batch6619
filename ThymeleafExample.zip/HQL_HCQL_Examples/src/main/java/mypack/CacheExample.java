package mypack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CacheExample 
{
     public static void main(String... g)
     {
    	 Configuration cfg = new Configuration();
 		cfg.configure("connect.cfg.xml"); 
        SessionFactory factory = cfg.buildSessionFactory();
        Session session1 = factory.openSession();
        
        Object o=session1.load(student.class,new Integer(103));
        
        student s=(student)o;
        
        System.out.println("Loaded object student name is___"+s.getStnm());
        System.out.println("Object Loaded successfully.....!!");  // loaded in first level cache  + global cache
        
        session1.close();
        
        
        System.out.println("------------------------------");
        System.out.println("Waiting......");
        

        try
			{
        		Thread.sleep(6000);
			}
        catch (Exception e) 
			{} 
        

        	System.out.println("6 seconds completed......!!!!!!!!");
         	
        	// hit the database and read a record
        	
        	Session session2 = factory.openSession();

        	Object o2=session2.load(student.class,new Integer(102));
 
        	student s2=(student)o2;
        	System.out.println("Loaded object student name is___"+s2.getStnm());
        	System.out.println("Object loaded from the database...!!");

        	session2.close();
        	        	
        	
        	// read data from global cache
        	
        	Session session3 = factory.openSession();
        	Object o3=session3.load(student.class,new Integer(103));
 
        	student s3=(student)o3;
        	System.out.println("Loaded object student name is___"+s3.getStnm());
        	System.out.println("Object loaded from global cache successfully.....!!");
        	session3.close();
        	       
     	}
	
}
