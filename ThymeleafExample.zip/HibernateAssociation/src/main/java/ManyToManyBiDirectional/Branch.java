package ManyToManyBiDirectional;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
import javax.persistence.ManyToMany;


@Entity
@Table(name="branch")
public class Branch 
{
	@Id
	@Column(name="branch_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int branch_id;
	
	@Column(name="branch_nm")
	private String branch_nm;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="Branch_Subjects",
		joinColumns= {@JoinColumn(name="branch_id")},
		inverseJoinColumns= {@JoinColumn(name="sub_id")}
			)
	private Set<Subjects> BH = new HashSet<Subjects>();


	public int getBranch_id() {
		return branch_id;
	}


	public void setBranch_id(int branch_id) {
		this.branch_id = branch_id;
	}


	public String getBranch_nm() {
		return branch_nm;
	}


	public void setBranch_nm(String branch_nm) {
		this.branch_nm = branch_nm;
	}


	public Set<Subjects> getBH() {
		return BH;
	}


	public void setBH(Set<Subjects> bH) {
		BH = bH;
	}
	
	
	
	
	
	

	
	
}
