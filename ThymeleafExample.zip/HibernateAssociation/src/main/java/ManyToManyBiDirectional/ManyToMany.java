package ManyToManyBiDirectional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;



import java.util.*;

public class ManyToMany 
{
	 public static void main( String[] args )
	    {
	    	Configuration  cfg = new Configuration();
			SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
			Session S = sf.openSession();
			
			S.getTransaction().begin();
			
			Branch B1 = new Branch();
			Branch B2 = new Branch();
			
			B1.setBranch_id(1111);
			B1.setBranch_nm("CSE");
			
			
			B2.setBranch_id(1112);
			B2.setBranch_nm("IT");
			
			
			Subjects S1 = new Subjects();
			Subjects S2 = new Subjects();
			Subjects S3 = new Subjects();
		
			S1.setSub_id(1);
			S1.setSub_nm("Computer graphics");
			
			S2.setSub_id(2);
			S2.setSub_nm("ASP");
			
			S3.setSub_id(3);
			S3.setSub_nm("JSP");
			
			Set<Subjects> s = new HashSet<Subjects>();
			s.add(S1);
			s.add(S2);
			s.add(S3);
						
			B1.setBH(s);
			
			Subjects S4 = new Subjects();
			Subjects S5 = new Subjects();
			Subjects S6 = new Subjects();
		
			S4.setSub_id(4);
			S4.setSub_nm("AI");
			
			S5.setSub_id(5);
			S5.setSub_nm("Machine Leraning");
			
			S6.setSub_id(6);
			S6.setSub_nm("Python");
			
			Set<Subjects> sb = new HashSet<Subjects>();
			
			sb.add(S4);
			sb.add(S5);
			sb.add(S6);
			
			B2.setBH(sb);
			
			S.save(S1);
			S.save(S2);
			S.save(S3);
			S.save(S4);
			S.save(S5);
			S.save(S6);
		
			S.save(B1);
			S.save(B2);
			
			
			Branch B3 = new Branch();
			Branch B4 = new Branch();
			
			B3.setBranch_id(3);
			B4.setBranch_id(4);
			B3.setBranch_nm("Electrical");
			B4.setBranch_nm("Electronics");
					
			Set<Branch> bh = new HashSet<Branch>();
			
			Subjects S7 = new Subjects();
			
			S7.setSub_id(7);
			S7.setSub_nm("Java");
			S7.setBH(bh);
			
			S.save(S7);
			
			S.save(B3);
			S.save(B4);
			
			S.getTransaction().commit();
			
			Criteria st = S.createCriteria(Subjects.class);
			Criteria cr = S.createCriteria(Branch.class);
		
			// arrange all the records in descending manner

			st.addOrder(Order.desc("sub_id"));
			cr.addOrder(Order.desc("branch_id"));
						
			List<Subjects> L1 = st.list();
			List<Branch> L2 = cr.list();
		
			L1.forEach(m->{
						System.out.println(m.getSub_id()+"     "+m.getSub_nm());  }
			);
		
																    							    		   
	    	S.close();
	    	sf.close();																					
	    }
				
}
