package ManyToManyBiDirectional;

import javax.persistence.*;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.ManyToMany;

@Entity
@Table(name="subjects")
public class Subjects 
{
	@Id
	@Column(name="sub_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sub_id;
	
	@Column(name="sub_nm")
	private String sub_nm;
	
	@ManyToMany(cascade = CascadeType.ALL,mappedBy="BH")
	private Set<Branch> BH = new HashSet<Branch>();


	public int getSub_id() {
		return sub_id;
	}


	public void setSub_id(int sub_id) {
		this.sub_id = sub_id;
	}


	public String getSub_nm() {
		return sub_nm;
	}


	public void setSub_nm(String sub_nm) {
		this.sub_nm = sub_nm;
	}


	public Set<Branch> getBH() {
		return BH;
	}


	public void setBH(Set<Branch> bH) {
		BH = bH;
	}
	
	

}
