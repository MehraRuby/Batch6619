package mypack;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="account")
public class Account
{

	@Id
	@Column(name="acc_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private int acc_id;

	@Column(name="acc_number")
	private String acc_number;
	
	
	@Column(name="empid")
	private int empid;


	public int getAcc_id() {
		return acc_id;
	}


	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}


	public String getAcc_number() {
		return acc_number;
	}


	public void setAcc_number(String acc_number) {
		this.acc_number = acc_number;
	}


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}
			
}
