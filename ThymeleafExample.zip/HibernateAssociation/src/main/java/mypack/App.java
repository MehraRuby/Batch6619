package mypack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.util.*;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration  cfg = new Configuration();
		SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
		Session S = sf.openSession();
		
		S.getTransaction().begin();
    	
		Account A1 = new Account();
		A1.setAcc_number("ACC_4");
		
		Account A2 = new Account();
		A2.setAcc_number("ACC_5");
		
		Account A3 = new Account();
		A3.setAcc_number("ACC_6");
		
		
		Employee E1 = new Employee();
		E1.setFirstnm("Mohan");
		E1.setLastnm("Verma");
		E1.setEmail("mohan@nova.com");
		
		Set<Account> AD = new HashSet<Account>();
		AD.add(A1);
		AD.add(A2);
		AD.add(A3);
		
		E1.setAC(AD);
		S.save(E1);
		
		S.getTransaction().commit();
    	S.close();
    	sf.close();
    	
    }
}
