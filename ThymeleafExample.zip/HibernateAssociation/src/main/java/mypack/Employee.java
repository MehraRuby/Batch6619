package mypack;


//one to many association
//1 to N relationship

import javax.persistence.*;
import java.util.Set;


@Entity
@Table(name="employee")
public class Employee 
{
	@Id
	@Column(name="empid")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int empid;
	
	@Column(name="email")
	private String email;
	
	@Column(name="firstnm")
	private String firstnm;
	
	@Column(name="lastnm")
	private String lastnm;
	
	@OneToMany(cascade = CascadeType.ALL)	
	@JoinTable(name="Employee_Account",
	joinColumns = {@JoinColumn(name="empid",referencedColumnName="empid")})
	private Set<Account> AC;
	

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmail() {
		return email;
	}

	public Set<Account> getAC() {
		return AC;
	}

	public void setAC(Set<Account> aC) {
		AC = aC;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstnm() {
		return firstnm;
	}

	public void setFirstnm(String firstnm) {
		this.firstnm = firstnm;
	}

	public String getLastnm() {
		return lastnm;
	}

	public void setLastnm(String lastnm) {
		this.lastnm = lastnm;
	}
		
}
