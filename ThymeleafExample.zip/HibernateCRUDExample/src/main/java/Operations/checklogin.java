package Operations;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import mypack.usertbl;

public class checklogin extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	RequestDispatcher rs=null;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
			int flag =0;
							 
			 Configuration  cfg = new Configuration();
			 SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
				Session S = sf.openSession();
				
		String em = request.getParameter("uid");
		
		Query q = S.createQuery("from usertbl u where u.user_email='"+em+"'");
		
		List<usertbl> L = q.list();
		Iterator I = L.iterator();
	
		usertbl u1 = new usertbl();
				
		while(I.hasNext())
		{
			u1 = (usertbl)I.next();
			if (u1.getUser_email().equals(em))
			{
				flag=1;
				break;				
			}
		}
		
		if (flag==1)
		{
				rs = request.getServletContext().getRequestDispatcher("/SearchCourseStudent");
				rs.forward(request, response);
		}
		else
				response.sendRedirect("Landing.jsp");
				
		S.close();
		sf.close();
	
		
	}

}
