package Operations;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;

import mypack.course;
import mypack.student;


public class deletecourse extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	RequestDispatcher rs=null;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
			Integer id=Integer.parseInt(request.getParameter("em"));
			
			 Configuration  cfg = new Configuration();
			 SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
			Session S = sf.openSession();
			S.getTransaction().begin();
			
			Query q = S.createQuery("from course c where c.crid ="+id);
					
			List<course> L = q.list();
			Iterator I = L.iterator();
			
			course c = new course();
			
			while(I.hasNext())
			{
				c = (course)I.next();						
				break;
			}
			
			S.delete(c);
			
			S.getTransaction().commit();
			
			Criteria st = S.createCriteria(student.class);
			Criteria cr = S.createCriteria(course.class);
			
			// arrange all the records in descending manner

			st.addOrder(Order.desc("stid"));
			cr.addOrder(Order.desc("crid"));
						
			List<student> LST = st.list();
			List<course> LCR = cr.list();
			
			
			rs = request.getServletContext().getRequestDispatcher("/browse.jsp");
			
			request.getServletContext().setAttribute("stud", LST);
			request.getServletContext().setAttribute("crse", LCR);
			
		
			rs.forward(request, response);
			S.close();
			sf.close();
			
		
		
	
	}

}
