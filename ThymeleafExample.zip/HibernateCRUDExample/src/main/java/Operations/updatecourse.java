package Operations;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;

import mypack.course;
import mypack.student;


public class updatecourse extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
  
	int flagcr=0;
	course c = new course();
	RequestDispatcher rs=null;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
				
						PrintWriter obj = response.getWriter();
						response.setContentType("text/html");
										
						 Configuration  cfg = new Configuration();
						 SessionFactory  sf  = cfg.configure("connect.cfg.xml").buildSessionFactory();	
							Session S = sf.openSession();
		
						S.getTransaction().begin();
						
						if(flagcr==0)
						{				
										
						Integer id=Integer.parseInt(request.getParameter("em"));
						Query q = S.createQuery("from course c where c.crid ="+id);
						
											
						List<course> L = q.list();
						Iterator I = L.iterator();
						
						while(I.hasNext())
						{
							c = (course)I.next();						
							break;
						}
						
						flagcr=1;
						
						obj.println("<form><table border=2 cellpadding=\'10px\'><tr><td>");
						obj.println(c.getCrid()+"</td><td>"+c.getCrnm()+"</td><td>");										
						obj.println("<input type=\'text\' name=\'price\' value="+c.getPrice()+"/></td><td>");
						obj.println(c.getDuration()+"</td><td>");
						obj.println("<input type=\'submit\' value=\'Update\'/></td></form></table>");
						
						}
						
						if(flagcr==1)
						{
							
							int p = Integer.parseInt(request.getParameter("price"));
							c.setPrice(p);
													
						
							S.saveOrUpdate(c);
							
							S.getTransaction().commit();
																										
							Criteria st = S.createCriteria(student.class);
							Criteria cr = S.createCriteria(course.class);
							
							// arrange all the records in descending manner

							st.addOrder(Order.desc("stid"));
							cr.addOrder(Order.desc("crid"));
										
							List<student> LST = st.list();
							List<course> LCR = cr.list();
							
							
							rs = request.getServletContext().getRequestDispatcher("/browse.jsp");
							
							request.getServletContext().setAttribute("stud", LST);
							request.getServletContext().setAttribute("crse", LCR);
							
							flagcr=0;
							rs.forward(request, response);
							S.close();
							sf.close();
							
						}
						
						
	
	}
}
